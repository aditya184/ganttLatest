import { Injectable } from '@angular/core';
import { UtilsService } from 'src/app/services/utils/utils.service';

@Injectable({
  providedIn: 'root'
})
export class LayoutService {

  constructor(private utilsService: UtilsService) { }

  cell() {

    var utils = this.utilsService.utils(),
      eventable = this.utilsService.eventable(),
      domHelpers =this.utilsService.domHelpers();

    var Cell = (function () {
      "use strict";

      function Cell(parent, config, factory, gantt) {
        if (parent) {
          this.$container = domHelpers.toNode(parent);
          this.$parent = parent;
        }
        // save config
        this.$config = utils.mixin(config, {
          headerHeight: 33
        });
        this.$gantt = gantt;
        this.$domEvents = gantt._createDomEventScope();
        // set id
        this.$id = config.id || "c" + utils.uid();

        this.$name = "cell";
        this.$factory = factory;

        eventable(this);

      }

      Cell.prototype.destructor = function () {
        this.$parent = this.$container = this.$view = null;
        var mouse = this.$gantt.$services.getService("mouseEvents");
        mouse.detach("click", "gantt_header_arrow", this._headerClickHandler);
        this.$domEvents.detachAll();
        this.callEvent("onDestroy", []);
        this.detachAllEvents();
      };
      Cell.prototype.cell = function (id) {
        return null;
      };

      Cell.prototype.scrollTo = function (left, top) {

        if (left * 1 == left) {
          this.$view.scrollLeft = left;
        }
        if (top * 1 == top) {
          this.$view.scrollTop = top;
        }
      };

      Cell.prototype.clear = function () {
        this.getNode().innerHTML = "";
        this.getNode().className = "gantt_layout_content";
        this.getNode().style.padding = "0";
      };

      Cell.prototype.resize = function (final) {
        if (this.$parent) {
          return this.$parent.resize(final);
        }

        if (final === false) {
          this.$preResize = true;
        }

        var topCont = this.$container;
        var x = topCont.offsetWidth;
        var y = topCont.offsetHeight;
        var topSize = this.getSize();
        if (topCont === document.body) {
          x = document.body.offsetWidth;
          y = document.body.offsetHeight;
        }
        if (x < topSize.minWidth) {
          x = topSize.minWidth;
        }
        if (x > topSize.maxWidth) {
          x = topSize.maxWidth;
        }
        if (y < topSize.minHeight) {
          y = topSize.minHeight;
        }
        if (y > topSize.maxHeight) {
          y = topSize.maxHeight;
        }
        this.setSize(x, y);

        if (!this.$preResize) {
          //	self.callEvent("onResize", [x, y]);
        }
        this.$preResize = false;
      };

      Cell.prototype.hide = function () {
        this._hide(true);
        this.resize();
      };
      Cell.prototype.show = function (force) {
        this._hide(false);
        if (force && this.$parent) {
          this.$parent.show();
        }
        this.resize();
      };
      Cell.prototype._hide = function (mode) {
        if (mode === true && this.$view.parentNode) {
          this.$view.parentNode.removeChild(this.$view);
        }
        else if (mode === false && !this.$view.parentNode) {
          var index = this.$parent.cellIndex(this.$id);
          this.$parent.moveView(this, index);
        }
        this.$config.hidden = mode;
      };
      Cell.prototype.$toHTML = function (content, css) {
        if (content === void 0) { content = ""; }
        css = [(css || ""), (this.$config.css || "")].join(" ");
        var obj = this.$config;
        var header = "";
        if (obj.raw) {
          content = typeof obj.raw === "string" ? obj.raw : "";
        }
        else {
          if (!content) {
            content = "<div class='gantt_layout_content' " + (css ? " class='" + css + "' " : "") + " >" + (obj.html || "") + "</div>";
          }
          if (obj.header) {
            var collapseIcon = obj.canCollapse ? "<div class='gantt_layout_header_arrow'></div>" : "";
            header = "<div class='gantt_layout_header'>" + collapseIcon + "<div class='gantt_layout_header_content'>" + obj.header + "</div></div>";
          }
        }
        return "<div class='gantt_layout_cell " + css + "' data-cell-id='" + this.$id + "'>" + header + content + "</div>";
      };
      Cell.prototype.$fill = function (node, parent) {
        this.$view = node;
        this.$parent = parent;
        this.init();
      };
      Cell.prototype.getNode = function () {
        return (this.$view.querySelector("gantt_layout_cell") || this.$view);
      };
      Cell.prototype.init = function () {
        // [NOT-GOOD] code is executed for each component, while it still has only one handler, it is no good

        var self = this;

        this._headerClickHandler = function (e) {
          var cellId = domHelpers.locateAttribute(e, "data-cell-id");
          if (cellId == self.$id) {
            self.toggle();
          }
        };

        var mouse = this.$gantt.$services.getService("mouseEvents");
        mouse.delegate("click", "gantt_header_arrow", this._headerClickHandler);

        this.callEvent("onReady", []);
      };
      Cell.prototype.toggle = function () {
        this.$config.collapsed = !this.$config.collapsed;
        this.resize();
      };
      Cell.prototype.getSize = function () {
        var size = {
          height: this.$config.height || 0,
          width: this.$config.width || 0,
          gravity: this.$config.gravity || 1,
          minHeight: this.$config.minHeight || 0,
          minWidth: this.$config.minWidth || 0,
          maxHeight: this.$config.maxHeight || 100000,
          maxWidth: this.$config.maxWidth || 100000
        };
        if (this.$config.collapsed) {
          var mode = this.$config.mode === "x";
          size[mode ? "width" : "height"] = size[mode ? "maxWidth" : "maxHeight"] = this.$config.headerHeight;
        }
        return size;
      };

      Cell.prototype.getContentSize = function () {

        var width = this.$lastSize.contentX;
        if (width !== width * 1) {
          width = this.$lastSize.width;
        }

        var height = this.$lastSize.contentY;
        if (height !== height * 1) {
          height = this.$lastSize.height;
        }

        return {
          width: width,
          height: height
        };
      };

      Cell.prototype._getBorderSizes = function () {
        var borders = {
          top: 0,
          right: 0,
          bottom: 0,
          left: 0,
          horizontal: 0,
          vertical: 0
        };
        if (this._currentBorders) {
          if (this._currentBorders[this._borders.left]) {
            borders.left = 1;
            borders.horizontal++;
          }

          if (this._currentBorders[this._borders.right]) {
            borders.right = 1;
            borders.horizontal++;
          }

          if (this._currentBorders[this._borders.top]) {
            borders.top = 1;
            borders.vertical++;
          }

          if (this._currentBorders[this._borders.bottom]) {
            borders.bottom = 1;
            borders.vertical++;
          }
        }

        return borders;

      };

      Cell.prototype.setSize = function (x, y) {
        this.$view.style.width = x + "px";
        this.$view.style.height = y + "px";

        var borders = this._getBorderSizes();
        var contentY = y - borders.vertical;
        var contentX = x - borders.horizontal;

        this.$lastSize = { x: x, y: y, contentX: contentX, contentY: contentY };
        if (this.$config.header) {
          this._sizeHeader();
        } else {
          this._sizeContent();
        }
      };

      Cell.prototype._borders = {
        "left": "gantt_layout_cell_border_left",
        "right": "gantt_layout_cell_border_right",
        "top": "gantt_layout_cell_border_top",
        "bottom": "gantt_layout_cell_border_bottom"
      };

      Cell.prototype._setBorders = function (css, view) {
        if (!view) {
          view = this;
        }
        var node = view.$view;

        for (var i in this._borders) {
          domHelpers.removeClassName(node, this._borders[i]);
        }

        if (typeof css == "string") {
          css = [css];
        }

        var cssHash = {};

        for (let i = 0; i < css.length; i++) {
          domHelpers.addClassName(node, css[i]);
          cssHash[css[i]] = true;
        }

        view._currentBorders = cssHash;
      };


      Cell.prototype._sizeContent = function () {
        var content = this.$view.childNodes[0];
        if (content && content.className == "gantt_layout_content") {
          content.style.height = this.$lastSize.contentY + "px";
        }
      };

      Cell.prototype._sizeHeader = function () {
        var size = this.$lastSize;
        size.contentY -= this.$config.headerHeight;
        var header = this.$view.childNodes[0];
        var content = this.$view.childNodes[1];
        var xLayout = this.$config.mode === "x";
        if (this.$config.collapsed) {
          content.style.display = "none";
          if (xLayout) {
            header.className = "gantt_layout_header collapsed_x";
            header.style.width = size.y + "px";
            var d = Math.floor(size.y / 2 - size.x / 2);
            header.style.transform = "rotate(90deg) translate(" + d + "px, " + d + "px)";
            content.style.display = "none";
          }
          else {
            header.className = "gantt_layout_header collapsed_y";
          }
        }
        else {
          if (xLayout) {
            header.className = "gantt_layout_header";
          }
          else {
            header.className = "gantt_layout_header vertical";
          }
          header.style.width = 'auto';
          header.style.transform = '';
          content.style.display = "";
          content.style.height = size.contentY + "px";
        }
        header.style.height = this.$config.headerHeight + "px";
      };
      return Cell;
    }());

    return Cell;


    /***/
  }

  layout() {

    var __extends = this.utilsService.extends(),
      domHelpers = this.utilsService.domHelpers(),
      Cell = this.cell();

    var Layout = (function (_super) {
      "use strict";

      __extends(Layout, _super);
      function Layout(parent, config, factory) {
        var _this = _super.apply(this, arguments) || this;

        if (parent)
          _this.$root = true;

        _this._parseConfig(config);
        _this.$name = "layout";
        return _this;
      }

      Layout.prototype.destructor = function () {
        if (this.$container && this.$view) {
          domHelpers.removeNode(this.$view);
        }

        for (var i = 0; i < this.$cells.length; i++) {
          var child = this.$cells[i];
          child.destructor();
        }
        this.$cells = [];

        _super.prototype.destructor.call(this);
      };

      Layout.prototype._resizeScrollbars = function (autosize, scrollbars) {
        var scrollChanged = false;
        var visibleScrollbars = [],
          hiddenSrollbars = [];

        function showScrollbar(scrollbar) {
          scrollbar.$parent.show();
          scrollChanged = true;
          visibleScrollbars.push(scrollbar);
        }
        function hideScrollbar(scrollbar) {
          scrollbar.$parent.hide();
          scrollChanged = true;
          hiddenSrollbars.push(scrollbar);
        }

        var scrollbar;
        for (var i = 0; i < scrollbars.length; i++) {
          scrollbar = scrollbars[i];

          if (autosize[scrollbar.$config.scroll]) {
            hideScrollbar(scrollbar);
          } else if (scrollbar.shouldHide()) {
            hideScrollbar(scrollbar);
          } else if (scrollbar.shouldShow()) {
            showScrollbar(scrollbar);
          } else {
            if (scrollbar.isVisible()) {
              visibleScrollbars.push(scrollbar);
            } else {
              hiddenSrollbars.push(scrollbar);
            }
          }
        }

        var visibleGroups = {};
        for (var i = 0; i < visibleScrollbars.length; i++) {
          if (visibleScrollbars[i].$config.group) {
            visibleGroups[visibleScrollbars[i].$config.group] = true;
          }
        }

        for (var i = 0; i < hiddenSrollbars.length; i++) {
          scrollbar = hiddenSrollbars[i];

          if (scrollbar.$config.group && visibleGroups[scrollbar.$config.group]) {
            showScrollbar(scrollbar);
          }
        }

        return scrollChanged;
      };

      Layout.prototype._syncCellSizes = function (groupName, newSize) {
        if (!groupName)
          return;

        var groups = {};

        this._eachChild(function (cell) {
          if (cell.$config.group && cell.$name != "scrollbar" && cell.$name != "resizer") {
            if (!groups[cell.$config.group]) {
              groups[cell.$config.group] = [];
            }
            groups[cell.$config.group].push(cell);
          }
        });

        if (groups[groupName]) {
          this._syncGroupSize(groups[groupName], newSize);
        }
        return groups[groupName];
      };

      Layout.prototype._syncGroupSize = function (cells, newSize) {
        if (!cells.length) return;

        var property = cells[0].$parent._xLayout ? "width" : "height";
        var direction = cells[0].$parent.getNextSibling(cells[0].$id) ? 1 : -1;

        for (var i = 0; i < cells.length; i++) {
          var ownSize = cells[i].getSize();

          var resizeSibling = direction > 0 ? cells[i].$parent.getNextSibling(cells[i].$id) : cells[i].$parent.getPrevSibling(cells[i].$id);
          if (resizeSibling.$name == "resizer") {
            resizeSibling = direction > 0 ? resizeSibling.$parent.getNextSibling(resizeSibling.$id) : resizeSibling.$parent.getPrevSibling(resizeSibling.$id);
          }
          var siblingSize = resizeSibling.getSize();

          if (resizeSibling[property]) {
            var totalGravity = ownSize.gravity + siblingSize.gravity;
            var totalSize = ownSize[property] + siblingSize[property];
            var k = totalGravity / totalSize;
            cells[i].$config.gravity = k * newSize;

            resizeSibling.$config[property] = totalSize - newSize;
            resizeSibling.$config.gravity = totalGravity - k * newSize;
          } else {


            cells[i].$config[property] = newSize;
          }

          var mainGrid = this.$gantt.$ui.getView("grid");
          if (mainGrid && cells[i].$content === mainGrid && !mainGrid.$config.scrollable) {
            this.$gantt.config.grid_width = newSize;
          }
        }
      };

      Layout.prototype.resize = function (startStage) {
        var mainCall = false;
        if (this.$root && !this._resizeInProgress) {
          this.callEvent("onBeforeResize", []);
          mainCall = true;
          this._resizeInProgress = true;
        }

        _super.prototype.resize.call(this, true);
        _super.prototype.resize.call(this, false);

        if (mainCall) {

          var contentViews = [];
          contentViews = contentViews.concat(this.getCellsByType("viewCell"));
          contentViews = contentViews.concat(this.getCellsByType("viewLayout"));
          contentViews = contentViews.concat(this.getCellsByType("hostCell"));

          var scrollbars = this.getCellsByType("scroller");

          for (var i = 0; i < contentViews.length; i++) {
            if (!contentViews[i].$config.hidden)
              contentViews[i].setContentSize();
          }

          var autosize = this._getAutosizeMode(this.$config.autosize);

          var scrollChanged = this._resizeScrollbars(autosize, scrollbars);

          if (this.$config.autosize) {
            this.autosize(this.$config.autosize);
            scrollChanged = true;
          }

          if (scrollChanged) {
            this.resize();
            for (var i = 0; i < contentViews.length; i++) {
              if (!contentViews[i].$config.hidden)
                contentViews[i].setContentSize();
            }
          }

          this.callEvent("onResize", []);
        }
        if (mainCall) {
          this._resizeInProgress = false;
        }
      };

      Layout.prototype._eachChild = function (code, cell) {
        cell = cell || this;
        code(cell);
        if (cell.$cells) {
          for (var i = 0; i < cell.$cells.length; i++) {
            this._eachChild(code, cell.$cells[i]);
          }
        }
      };

      Layout.prototype.isChild = function (view) {
        var res = false;
        this._eachChild(function (child) {
          if (child === view || child.$content === view) {
            res = true;
          }
        });
        return res;
      };

      Layout.prototype.getCellsByType = function (type) {
        var res = [];
        if (type === this.$name) {
          res.push(this);
        }

        if (this.$content && this.$content.$name == type) {
          res.push(this.$content);
        }

        if (this.$cells) {
          for (var i = 0; i < this.$cells.length; i++) {
            var children = Layout.prototype.getCellsByType.call(this.$cells[i], type);
            if (children.length) {
              res.push.apply(res, children);
            }
          }
        }
        return res;
      };

      Layout.prototype.getNextSibling = function (cellId) {
        var index = this.cellIndex(cellId);
        if (index >= 0 && this.$cells[index + 1]) {
          return this.$cells[index + 1];
        } else {
          return null;
        }
      };

      Layout.prototype.getPrevSibling = function (cellId) {
        var index = this.cellIndex(cellId);
        if (index >= 0 && this.$cells[index - 1]) {
          return this.$cells[index - 1];
        } else {
          return null;
        }
      };


      Layout.prototype.cell = function (id) {
        for (var i = 0; i < this.$cells.length; i++) {
          var child = this.$cells[i];
          if (child.$id === id) {
            return child;
          }
          var sub = child.cell(id);
          if (sub) {
            return sub;
          }
        }
      };
      Layout.prototype.cellIndex = function (id) {
        for (var i = 0; i < this.$cells.length; i++) {
          if (this.$cells[i].$id === id) {
            return i;
          }
        }
        return -1;
      };
      Layout.prototype.moveView = function (view, ind) {
        if (this.$cells[ind] !== view) {
          return window.alert("Not implemented");
        }
        else {
          ind += this.$config.header ? 1 : 0;
          var node = this.$view;
          if (ind >= node.childNodes.length) {
            node.appendChild(view.$view);
          }
          else {
            node.insertBefore(view.$view, node.childNodes[ind]);
          }
        }
      };
      Layout.prototype._parseConfig = function (config) {
        this.$cells = [];
        this._xLayout = !config.rows;
        var cells = config.rows || config.cols || config.views;
        for (var i = 0; i < cells.length; i++) {
          var cell = cells[i];
          cell.mode = this._xLayout ? "x" : "y";
          var $content = this.$factory.initUI(cell, this);
          if (!$content) {
            cells.splice(i, 1);
            i--;
          } else {
            $content.$parent = this;
            this.$cells.push($content);
          }
        }
      };
      Layout.prototype.getCells = function () {
        return this.$cells;
      };
      Layout.prototype.render = function () {
        var view = domHelpers.insertNode(this.$container, this.$toHTML());
        this.$fill(view, null);
        this.callEvent("onReady", []);
        this.resize();

        // do simple repaint after the first call
        this.render = this.resize;
      };
      Layout.prototype.$fill = function (node, parent) {
        this.$view = node;
        this.$parent = parent;
        var cells = domHelpers.getChildNodes(node, "gantt_layout_cell");
        for (var i = cells.length - 1; i >= 0; i--) {
          var sub = this.$cells[i];
          sub.$fill(cells[i], this);
          // initially hidden cell
          if (sub.$config.hidden) {
            sub.$view.parentNode.removeChild(sub.$view);
          }
        }
      };
      Layout.prototype.$toHTML = function () {
        var mode = this._xLayout ? "x" : "y";
        var html = [];
        for (var i = 0; i < this.$cells.length; i++) {
          html.push(this.$cells[i].$toHTML());
        }
        return _super.prototype.$toHTML.call(this, html.join(""), (this.$root ? "gantt_layout_root " : "") + "gantt_layout gantt_layout_" + mode);
      };

      Layout.prototype.getContentSize = function (mode) {
        var contentWidth = 0,
          contentHeight = 0;

        var cellSize, cell, borders;
        for (var i = 0; i < this.$cells.length; i++) {
          cell = this.$cells[i];
          if (cell.$config.hidden)
            continue;

          cellSize = cell.getContentSize(mode);

          if (cell.$config.view === "scrollbar" && mode[cell.$config.scroll]) {
            cellSize.height = 0;
            cellSize.width = 0;
          }

          if (cell.$config.resizer) {
            if (this._xLayout) {
              cellSize.height = 0;
            } else {
              cellSize.width = 0;
            }
          }

          borders = cell._getBorderSizes();

          if (this._xLayout) {
            contentWidth += (cellSize.width + borders.horizontal);
            contentHeight = Math.max(contentHeight, (cellSize.height + borders.vertical));
          } else {
            contentWidth = Math.max(contentWidth, cellSize.width + borders.horizontal);
            contentHeight += cellSize.height + borders.vertical;
          }
        }

        borders = this._getBorderSizes();
        contentWidth += borders.horizontal;
        contentHeight += borders.vertical;

        if (this.$root) {
          contentWidth += 1;
          contentHeight += 1;
        }

        return {
          width: contentWidth,
          height: contentHeight
        };
      };

      Layout.prototype._cleanElSize = function (value) {
        return ((value || "").toString().replace("px", "") * 1 || 0);
      };
      Layout.prototype._getBoxStyles = function (div) {
        var computed = null;
        if (window.getComputedStyle) {
          computed = window.getComputedStyle(div, null);
        } else {
          //IE with elem.currentStyle does not calculate sizes from %, so will use the default approach
          computed = {
            "width": div.clientWidth,
            "height": div.clientHeight
          };
        }
        var properties = [
          "width",
          "height",

          "paddingTop",
          "paddingBottom",
          "paddingLeft",
          "paddingRight",

          "borderLeftWidth",
          "borderRightWidth",
          "borderTopWidth",
          "borderBottomWidth"
        ];
        var styles: any = {
          boxSizing: (computed.boxSizing == "border-box")
        };

        if (computed.MozBoxSizing) {
          styles.boxSizing = (computed.MozBoxSizing == "border-box");
        }
        for (var i = 0; i < properties.length; i++) {
          styles[properties[i]] = computed[properties[i]] ? this._cleanElSize(computed[properties[i]]) : 0;
        }


        var box = {
          horPaddings: (styles.paddingLeft + styles.paddingRight + styles.borderLeftWidth + styles.borderRightWidth),
          vertPaddings: (styles.paddingTop + styles.paddingBottom + styles.borderTopWidth + styles.borderBottomWidth),
          borderBox: styles.boxSizing,
          innerWidth: styles.width,
          innerHeight: styles.height,
          outerWidth: styles.width,
          outerHeight: styles.height
        };


        if (box.borderBox) {
          box.innerWidth -= box.horPaddings;
          box.innerHeight -= box.vertPaddings;
        } else {
          box.outerWidth += box.horPaddings;
          box.outerHeight += box.vertPaddings;
        }

        return box;
      };

      Layout.prototype._getAutosizeMode = function (config) {
        var res = { x: false, y: false };
        if (config === "xy") {
          res.x = res.y = true;
        } else if (config === "y" || config === true) {
          res.y = true;
        } else if (config === "x") {
          res.x = true;
        }
        return res;
      };

      Layout.prototype.autosize = function (mode) {
        var res = this._getAutosizeMode(mode);
        var boxSizes = this._getBoxStyles(this.$container);
        var contentSizes = this.getContentSize(mode);

        var node = this.$container;
        if (res.x) {
          if (boxSizes.borderBox) {
            contentSizes.width += boxSizes.horPaddings;
          }
          node.style.width = contentSizes.width + "px";
        }
        if (res.y) {
          if (boxSizes.borderBox) {
            contentSizes.height += boxSizes.vertPaddings;
          }
          node.style.height = contentSizes.height + "px";
        }
      };

      Layout.prototype.getSize = function () {
        this._sizes = [];
        var width = 0;
        var minWidth = 0;
        var maxWidth = 100000;
        var height = 0;
        var maxHeight = 100000;
        var minHeight = 0;

        for (var i = 0; i < this.$cells.length; i++) {

          var size = this._sizes[i] = this.$cells[i].getSize();
          if (this.$cells[i].$config.hidden) {
            continue;
          }
          if (this._xLayout) {
            if (!size.width && size.minWidth) {
              width += size.minWidth;
            }
            else {
              width += size.width;
            }
            maxWidth += size.maxWidth;
            minWidth += size.minWidth;
            height = Math.max(height, size.height);
            maxHeight = Math.min(maxHeight, size.maxHeight); // min of maxHeight
            minHeight = Math.max(minHeight, size.minHeight); // max of minHeight
          }
          else {
            if (!size.height && size.minHeight) {
              height += size.minHeight;
            }
            else {
              height += size.height;
            }
            maxHeight += size.maxHeight;
            minHeight += size.minHeight;
            width = Math.max(width, size.width);
            maxWidth = Math.min(maxWidth, size.maxWidth); // min of maxWidth
            minWidth = Math.max(minWidth, size.minWidth); // max of minWidth
          }
        }
        var self = _super.prototype.getSize.call(this);
        // maxWidth
        if (self.maxWidth >= 100000) {
          self.maxWidth = maxWidth;
        }
        // maxHeight
        if (self.maxHeight >= 100000) {
          self.maxHeight = maxHeight;
        }
        // minWidth
        self.minWidth = self.minWidth !== self.minWidth ? 0 : self.minWidth;// || self.width || Math.max(minWidth, width);
        // minHeight
        self.minHeight = self.minHeight !== self.minHeight ? 0 : self.minHeight;//self.minHeight || self.height || Math.max(minHeight, height);
        // sizes with paddings and margins
        if (this._xLayout) {
          self.minWidth += this.$config.margin * (this.$cells.length) || 0;
          self.minWidth += this.$config.padding * 2 || 0;
          self.minHeight += (this.$config.padding * 2) || 0;
        }
        else {
          self.minHeight += this.$config.margin * (this.$cells.length) || 0;
          self.minHeight += (this.$config.padding * 2) || 0;
        }

        return self;
      };
      // calc total gravity and free space
      Layout.prototype._calcFreeSpace = function (s, cell, xLayout) {
        var min = xLayout ? cell.minWidth : cell.minHeight;
        var max = xLayout ? cell.maxWidth : cell.maxWidth;
        var side = s;
        if (!side) {
          side = Math.floor(this._free / this._gravity * cell.gravity);
          if (side > max) {
            side = max;
            this._free -= side;
            this._gravity -= cell.gravity;
          }
          if (side < min) {
            side = min;
            this._free -= side;
            this._gravity -= cell.gravity;
          }
        }
        else {
          if (side > max) {
            side = max;
          }
          if (side < min) {
            side = min;
          }
          this._free -= side;
        }
        return side;
      };
      Layout.prototype._calcSize = function (s, size, xLayout) {
        var side = s;
        var min = xLayout ? size.minWidth : size.minHeight;
        var max = xLayout ? size.maxWidth : size.maxHeight;
        if (!side) {
          side = Math.floor(this._free / this._gravity * size.gravity);
        }
        if (side > max) {
          side = max;
        }
        if (side < min) {
          side = min;
        }
        return side;
      };

      Layout.prototype._configureBorders = function () {
        if (this.$root) {
          this._setBorders([
            this._borders.left,
            this._borders.top,
            this._borders.right,
            this._borders.bottom
          ],
            this);
        }

        var borderClass = this._xLayout ? this._borders.right : this._borders.bottom;

        var cells = this.$cells;

        var lastVisibleIndex = cells.length - 1;
        for (var i = lastVisibleIndex; i >= 0; i--) {
          if (!cells[i].$config.hidden) {
            lastVisibleIndex = i;
            break;
          }
        }

        for (var i = 0; i < cells.length; i++) {
          if (cells[i].$config.hidden) {
            continue;
          }

          var lastCell = i >= lastVisibleIndex;
          var borderColorClass = "";
          if (!lastCell && cells[i + 1]) {
            if (cells[i + 1].$config.view == "scrollbar") {
              if (this._xLayout) {
                lastCell = true;
              } else {
                borderColorClass = "gantt_layout_cell_border_transparent";
              }

            }
          }


          this._setBorders(lastCell ? [] : [borderClass, borderColorClass], cells[i]);
        }
      };

      Layout.prototype._updateCellVisibility = function () {
        var oldVisibleCells = this._visibleCells || {};
        var firstCall = !this._visibleCells;
        var visibleCells = {};
        var cell;
        for (var i = 0; i < this._sizes.length; i++) {
          cell = this.$cells[i];

          if (!firstCall && cell.$config.hidden && oldVisibleCells[cell.$id]) {
            cell._hide(true);
          } else if (!cell.$config.hidden && !oldVisibleCells[cell.$id]) {
            cell._hide(false);
          }

          if (!cell.$config.hidden) {
            visibleCells[cell.$id] = true;
          }
        }
        this._visibleCells = visibleCells;
      };

      Layout.prototype.setSize = function (x, y) {
        this._configureBorders();
        _super.prototype.setSize.call(this, x, y);
        y = this.$lastSize.contentY;
        x = this.$lastSize.contentX;

        var padding = (this.$config.padding || 0);
        this.$view.style.padding = padding + "px";
        this._gravity = 0;
        this._free = this._xLayout ? x : y;
        this._free -= padding * 2;
        // calc all gravity

        var cell,
          size;

        this._updateCellVisibility();

        for (var i = 0; i < this._sizes.length; i++) {
          cell = this.$cells[i];

          if (cell.$config.hidden) {
            continue;
          }
          var margin = (this.$config.margin || 0);
          if (cell.$name == "resizer" && !margin) {
            margin = -1;
          }

          // set margins to child cell
          var cellView = cell.$view;

          var marginSide = this._xLayout ? "marginRight" : "marginBottom";
          if (i !== this.$cells.length - 1) {
            cellView.style[marginSide] = margin + "px";
            this._free -= margin; // calc free space without margin
          }
          size = this._sizes[i];
          if (this._xLayout) {
            if (!size.width) {
              this._gravity += size.gravity;
            }
          }
          else {
            if (!size.height) {
              this._gravity += size.gravity;
            }
          }
        }
        for (var i = 0; i < this._sizes.length; i++) {
          cell = this.$cells[i];

          if (cell.$config.hidden) {
            continue;
          }
          size = this._sizes[i];
          var width = size.width;
          var height = size.height;
          if (this._xLayout) {
            this._calcFreeSpace(width, size, true);
          }
          else {
            this._calcFreeSpace(height, size, false);
          }
        }
        for (var i = 0; i < this.$cells.length; i++) {
          cell = this.$cells[i];

          if (cell.$config.hidden) {
            continue;
          }
          size = this._sizes[i];
          var dx = void 0;
          var dy = void 0;
          if (this._xLayout) {
            dx = this._calcSize(size.width, size, true);
            dy = y - padding * 2; // layout height without paddings
          }
          else {
            dx = x - padding * 2; // layout width without paddings
            dy = this._calcSize(size.height, size, false);
          }

          cell.setSize(dx, dy);
        }

      };

      return Layout;
    }(Cell));

    return Layout;

    /***/
  }

  resizerCell() {

    return null;

    /***/
  }

  scrollbarCell() {

    var __extends = this.utilsService.extends(),
      domHelpers = this.utilsService.domHelpers(),
      utils = this.utilsService.utils(),
      env = this.utilsService.env(),
      Cell = this.cell();

    var ScrollbarCell = (function (_super) {
      "use strict";

      __extends(ScrollbarCell, _super);
      function ScrollbarCell(parent, config, factory, gantt) {

        var _this = _super.apply(this, arguments) || this;
        this.$config = utils.mixin(config, { scroll: "x" });
        _this._scrollHorizontalHandler = utils.bind(_this._scrollHorizontalHandler, _this);
        _this._scrollVerticalHandler = utils.bind(_this._scrollVerticalHandler, _this);
        _this._outerScrollVerticalHandler = utils.bind(_this._outerScrollVerticalHandler, _this);
        _this._outerScrollHorizontalHandler = utils.bind(_this._outerScrollHorizontalHandler, _this);
        _this._mouseWheelHandler = utils.bind(_this._mouseWheelHandler, _this);

        this.$config.hidden = true;
        var size = gantt.config.scroll_size;

        if (gantt.env.isIE) {
          // full element height/width must be bigger than just a browser scrollbar,
          // otherwise the scrollbar element won't be scrolled on click
          size += 1;
        }

        if (this._isHorizontal()) {
          _this.$config.height = size;
          _this.$parent.$config.height = size;
        } else {
          _this.$config.width = size;
          _this.$parent.$config.width = size;
        }

        this.$config.scrollPosition = 0;

        _this.$name = "scroller";
        return _this;
      }

      ScrollbarCell.prototype.init = function (container) {
        container.innerHTML = this.$toHTML();
        this.$view = container.firstChild;

        if (!this.$view) {
          this.init();
        }
        if (this._isVertical()) {
          this._initVertical();
        } else {
          this._initHorizontal();
        }
        this._initMouseWheel();
        this._initLinkedViews();
      };

      ScrollbarCell.prototype.$toHTML = function () {
        var className = this._isHorizontal() ? "gantt_hor_scroll" : "gantt_ver_scroll";
        return "<div class='gantt_layout_cell " + className + "'><div style='" + (this._isHorizontal() ? "width:2000px" : "height:2000px") + "'></div></div>";
      };

      ScrollbarCell.prototype._getRootParent = function () {
        var parent = this.$parent;
        while (parent && parent.$parent) {
          parent = parent.$parent;
        }
        if (parent) {
          return parent;
        }
      };


      function eachCell(root, res) {
        res.push(root);
        if (root.$cells) {
          for (var i = 0; i < root.$cells.length; i++) {
            eachCell(root.$cells[i], res);
          }
        }
      }
      ScrollbarCell.prototype._eachView = function () {
        var res = [];
        eachCell(this._getRootParent(), res);
        return res;
      };

      ScrollbarCell.prototype._getLinkedViews = function () {
        var views = this._eachView();
        var res = [];
        for (var i = 0; i < views.length; i++) {
          if (views[i].$config && ((this._isVertical() && views[i].$config.scrollY == this.$id) || (this._isHorizontal() && views[i].$config.scrollX == this.$id))) {
            res.push(views[i]);
          }
        }
        return res;
      };


      ScrollbarCell.prototype._initHorizontal = function () {
        this.$scroll_hor = this.$view;
        this.$domEvents.attach(this.$view, "scroll", this._scrollHorizontalHandler);

      };

      ScrollbarCell.prototype._initLinkedViews = function () {
        var views = this._getLinkedViews();
        var css = this._isVertical() ? "gantt_layout_outer_scroll gantt_layout_outer_scroll_vertical" : "gantt_layout_outer_scroll gantt_layout_outer_scroll_horizontal";
        for (var i = 0; i < views.length; i++) {
          //views[i].$config.css = [views[i].$config.css || "", css].join(" ");
          domHelpers.addClassName(views[i].$view || views[i].getNode(), css);
        }
      };

      ScrollbarCell.prototype._initVertical = function () {
        this.$scroll_ver = this.$view;
        this.$domEvents.attach(this.$view, "scroll", this._scrollVerticalHandler);
      };

      ScrollbarCell.prototype._updateLinkedViews = function () {
      };

      ScrollbarCell.prototype._initMouseWheel = function () {
        var ff = env.isFF;
        if (ff)
          this.$domEvents.attach(this._getRootParent().$view, "wheel", this._mouseWheelHandler);
        else
          this.$domEvents.attach(this._getRootParent().$view, "mousewheel", this._mouseWheelHandler);
      };




      ScrollbarCell.prototype.scrollHorizontally = function (left) {
        if (this._scrolling) return;
        this._scrolling = true;

        this.$scroll_hor.scrollLeft = left;
        this.$config.codeScrollLeft = left;
        left = this.$scroll_hor.scrollLeft;

        var views = this._getLinkedViews();
        for (var i = 0; i < views.length; i++) {
          if (views[i].scrollTo) {
            views[i].scrollTo(left, undefined);
          }
        }
        var oldSize = this.$config.scrollPosition;
        this.$config.scrollPosition = left;
        this.callEvent("onScroll", [oldSize, left, this.$config.scroll]);
        this._scrolling = false;
      };
      ScrollbarCell.prototype.scrollVertically = function (top) {
        if (this._scrolling) return;
        this._scrolling = true;

        this.$scroll_ver.scrollTop = top;
        top = this.$scroll_ver.scrollTop;

        var views = this._getLinkedViews();

        for (var i = 0; i < views.length; i++) {
          if (views[i].scrollTo) {
            views[i].scrollTo(undefined, top);
          }
        }
        var oldSize = this.$config.scrollPosition;
        this.$config.scrollPosition = top;
        this.callEvent("onScroll", [oldSize, top, this.$config.scroll]);
        this._scrolling = false;
      };

      ScrollbarCell.prototype._isVertical = function () {
        return this.$config.scroll == "y";
      };
      ScrollbarCell.prototype._isHorizontal = function () {
        return this.$config.scroll == "x";
      };
      ScrollbarCell.prototype._scrollHorizontalHandler = function (e) {
        if (this._isVertical() || this._scrolling) {
          return;
        }
        var date: any = new Date();
        //in safari we can catch previous onscroll after setting new value from mouse-wheel event
        //set delay to prevent value drifiting
        if ((date) - (this._wheel_time || 0) < 100) return true;
        if (this.$gantt._touch_scroll_active) return;
        var left = this.$scroll_hor.scrollLeft;

        this.scrollHorizontally(left);

        this._oldLeft = this.$scroll_hor.scrollLeft;
      };
      ScrollbarCell.prototype._outerScrollHorizontalHandler = function (e) {
        if (this._isVertical()) {
          return;
        }
      };

      ScrollbarCell.prototype.show = function () {
        this.$parent.show();
      };
      ScrollbarCell.prototype.hide = function () {
        this.$parent.hide();
      };

      ScrollbarCell.prototype._getScrollSize = function () {
        var scrollSize = 0;
        var outerSize = 0;
        var isHorizontal = this._isHorizontal();

        var linked = this._getLinkedViews();
        var view;
        var scrollProperty = isHorizontal ? "scrollWidth" : "scrollHeight",
          innerSizeProperty = isHorizontal ? "contentX" : "contentY";
        var outerProperty = isHorizontal ? "x" : "y";
        var offset = this._getScrollOffset();

        for (var i = 0; i < linked.length; i++) {
          view = linked[i];
          if (!(view && view.$content && view.$content.getSize && !view.$config.hidden)) continue;

          var sizes = view.$content.getSize();
          var cellScrollSize;
          if (sizes.hasOwnProperty(scrollProperty)) {
            cellScrollSize = sizes[scrollProperty];
          } else {
            cellScrollSize = sizes[innerSizeProperty];
          }

          if (offset) {
            // precalculated vertical/horizontal offsets of scrollbar to emulate 4.x look
            if (sizes[innerSizeProperty] > sizes[outerProperty] && sizes[innerSizeProperty] > scrollSize && (cellScrollSize > (sizes[outerProperty] - offset + 2))) {
              scrollSize = cellScrollSize + (isHorizontal ? 0 : 2);
              outerSize = sizes[outerProperty];
            }
          } else {
            var nonScrollableSize = Math.max(sizes[innerSizeProperty] - cellScrollSize, 0);
            var scrollableViewPortSize = Math.max(sizes[outerProperty] - nonScrollableSize, 0);
            cellScrollSize = cellScrollSize + nonScrollableSize;

            if (cellScrollSize > scrollableViewPortSize && (cellScrollSize > scrollSize)) {
              //|| (cellScrollSize === scrollSize && sizes[outerProperty] < outerSize) // same scroll width but smaller scrollable view port

              scrollSize = cellScrollSize;
              outerSize = sizes[outerProperty];
            }
          }
        }

        return {
          outerScroll: outerSize,
          innerScroll: scrollSize
        };
      };

      ScrollbarCell.prototype.scroll = function (position) {
        if (this._isHorizontal()) {
          this.scrollHorizontally(position);
        } else {
          this.scrollVertically(position);
        }
      };

      ScrollbarCell.prototype.getScrollState = function () {
        return {
          visible: this.isVisible(),
          direction: this.$config.scroll,
          size: this.$config.outerSize,
          scrollSize: this.$config.scrollSize || 0,
          position: this.$config.scrollPosition || 0
        };
      };

      ScrollbarCell.prototype.setSize = function (width, height) {
        _super.prototype.setSize.apply(this, arguments);

        var scrollSizes = this._getScrollSize();

        var ownSize = (this._isVertical() ? height : width) - this._getScrollOffset() + (this._isHorizontal() ? 1 : 0);

        if (scrollSizes.innerScroll && ownSize > scrollSizes.outerScroll) {
          scrollSizes.innerScroll += (ownSize - scrollSizes.outerScroll);
        }
        this.$config.scrollSize = scrollSizes.innerScroll;

        this.$config.width = width;
        this.$config.height = height;
        this._setScrollSize(scrollSizes.innerScroll);
      };

      ScrollbarCell.prototype.isVisible = function () {
        return !!(this.$parent && this.$parent.$view.parentNode);
      };

      ScrollbarCell.prototype.shouldShow = function () {
        var scrollSizes = this._getScrollSize();
        if (!scrollSizes.innerScroll && (this.$parent && this.$parent.$view.parentNode)) {
          return false;
        } else if (scrollSizes.innerScroll && !(this.$parent && this.$parent.$view.parentNode)) {
          return true;
        } else {
          return false;
        }
      };

      ScrollbarCell.prototype.shouldHide = function () {
        var scrollSizes = this._getScrollSize();
        if (!scrollSizes.innerScroll && (this.$parent && this.$parent.$view.parentNode)) {
          return true;
        } else {
          return false;
        }
      };


      ScrollbarCell.prototype.toggleVisibility = function () {
        if (this.shouldHide()) {
          this.hide();
        } else if (this.shouldShow()) {
          this.show();
        }
      };

      ScrollbarCell.prototype._getScaleOffset = function (view) {
        var offset = 0;
        if (view && (view.$config.view == "timeline" || view.$config.view == "grid")) {
          offset = view.$content.$getConfig().scale_height;
        }
        return offset;
      };

      ScrollbarCell.prototype._getScrollOffset = function () {
        var offset = 0;
        if (this._isVertical()) {
          var parentLayout = this.$parent.$parent;
          offset = Math.max(
            this._getScaleOffset(parentLayout.getPrevSibling(this.$parent.$id)),
            this._getScaleOffset(parentLayout.getNextSibling(this.$parent.$id))
          );
        } else {
          var linked = this._getLinkedViews();

          for (var i = 0; i < linked.length; i++) {
            var view = linked[i],
              vparent = view.$parent;
            var cells = vparent.$cells;

            var last = cells[cells.length - 1];

            if (last && last.$config.view == "scrollbar" && last.$config.hidden === false) {
              offset = last.$config.width;
              break;
            }

          }
        }
        return offset || 0;
      };

      ScrollbarCell.prototype._setScrollSize = function (size) {
        var property = this._isHorizontal() ? "width" : "height";
        var scrollbar = this._isHorizontal() ? this.$scroll_hor : this.$scroll_ver;

        var offset = this._getScrollOffset();

        var node = scrollbar.firstChild;

        if (offset) {
          if (this._isVertical()) {

            this.$config.outerSize = (this.$config.height - offset + 3);
            scrollbar.style.height = this.$config.outerSize + "px";
            scrollbar.style.top = (offset - 1) + "px";
            domHelpers.addClassName(scrollbar, this.$parent._borders.top);
            domHelpers.addClassName(scrollbar.parentNode, "gantt_task_vscroll");
          } else {
            this.$config.outerSize = (this.$config.width - offset + 1);
            scrollbar.style.width = this.$config.outerSize + "px";
            //domHelpers.addClassName(scrollbar, this.$parent._borders.right);
          }
        } else {
          scrollbar.style.top = "auto";
          domHelpers.removeClassName(scrollbar, this.$parent._borders.top);
          domHelpers.removeClassName(scrollbar.parentNode, "gantt_task_vscroll");
          this.$config.outerSize = this.$config.height;
        }

        node.style[property] = size + "px";
      };

      ScrollbarCell.prototype._scrollVerticalHandler = function (e) {
        if (this._scrollHorizontalHandler() || this._scrolling) {
          return;
        }

        if (this.$gantt._touch_scroll_active) return;
        var top = this.$scroll_ver.scrollTop;
        var prev = this._oldTop;
        if (top == prev) return;

        this.scrollVertically(top);

        this._oldTop = this.$scroll_ver.scrollTop;

      };
      ScrollbarCell.prototype._outerScrollVerticalHandler = function (e) {
        if (this._scrollHorizontalHandler()) {
          return;
        }
      };

      ScrollbarCell.prototype._checkWheelTarget = function (targetNode) {
        var connectedViews = this._getLinkedViews().concat(this);

        for (var i = 0; i < connectedViews.length; i++) {
          var node = connectedViews[i].$view;
          if (domHelpers.isChildOf(targetNode, node)) {
            return true;
          }
        }

        return false;
      };

      ScrollbarCell.prototype._mouseWheelHandler = function (e) {
        var target = e.target || e.srcElement;

        if (!this._checkWheelTarget(target))
          return;

        this._wheel_time = new Date();

        var res: any = {};
        var ff = env.isFF;
        var wx = ff ? (e.deltaX * -20) : e.wheelDeltaX * 2;
        var wy = ff ? (e.deltaY * -40) : e.wheelDelta;

        if (e.shiftKey && !(e.deltaX || e.wheelDeltaX)) {
          // shift+mousewheel for horizontal scroll
          wx = wy * 2;
          wy = 0;
        }

        if (wx && Math.abs(wx) > Math.abs(wy)) {
          if (this._isVertical()) {
            return;
          }

          if (res.x) return true;//no horisontal scroll, must not block scrolling
          if (!this.$scroll_hor || !this.$scroll_hor.offsetWidth) return true;

          var dir = wx / -40;
          var oldLeft = this._oldLeft;
          var left = oldLeft + dir * 30;
          this.scrollHorizontally(left);
          this.$scroll_hor.scrollLeft = left;
          // not block scroll if position hasn't changed
          if (oldLeft == this.$scroll_hor.scrollLeft) {
            return true;
          }

          this._oldLeft = this.$scroll_hor.scrollLeft;
        } else {
          if (this._isHorizontal()) {
            return;
          }

          if (res.y) return true;//no vertical scroll, must not block scrolling
          if (!this.$scroll_ver || !this.$scroll_ver.offsetHeight) return true;

          var dir = wy / -40;
          if (typeof wy == "undefined")
            dir = e.detail;

          var oldTop = this._oldTop;
          var top = this.$scroll_ver.scrollTop + dir * 30;

          //if(!this.$gantt.config.prevent_default_scroll &&
          //	(this.$gantt._cached_scroll_pos && ((this.$gantt._cached_scroll_pos.y == top) || (this.$gantt._cached_scroll_pos.y <= 0 && top <= 0)))) return true;


          this.scrollVertically(top);
          this.$scroll_ver.scrollTop = top;

          // not block scroll if position hasn't changed
          if (oldTop == this.$scroll_ver.scrollTop) {
            return true;
          }
          this._oldTop = this.$scroll_ver.scrollTop;
        }

        if (e.preventDefault)
          e.preventDefault();
        e.cancelBubble = true;
        return false;
      };

      return ScrollbarCell;
    })(Cell);

    return ScrollbarCell;

    /***/
  }

  viewCell() {

    var __extends = this.utilsService.extends(),
      utils = this.utilsService.utils(),
      Cell = this.cell();

    var ViewCell = (function (_super) {
      "use strict";

      __extends(ViewCell, _super);
      function ViewCell(parent, config, factory) {

        var _this = _super.apply(this, arguments) || this;

        if (config.view) {
          if (config.id) {
            // pass id to the nested view
            this.$id = utils.uid();
          }
          var childConfig = utils.copy(config);
          delete childConfig.config;
          delete childConfig.templates;

          this.$content = this.$factory.createView(config.view, this, childConfig, this);
          if (!this.$content)
            return false;
        }

        _this.$name = "viewCell";
        return _this;
      }

      ViewCell.prototype.destructor = function () {
        this.clear();
        _super.prototype.destructor.call(this);
      };

      ViewCell.prototype.clear = function () {

        this.$initialized = false;

        // call destructor
        if (this.$content) {
          var method = this.$content.unload || this.$content.destructor;
          if (method) {
            method.call(this.$content);
          }
        }

        _super.prototype.clear.call(this);

      };

      ViewCell.prototype.scrollTo = function (left, top) {

        if (this.$content && this.$content.scrollTo) {
          this.$content.scrollTo(left, top);
        } else {
          _super.prototype.scrollTo.call(this, left, top);
        }
      };

      ViewCell.prototype._setContentSize = function (x, y) {
        var borders = this._getBorderSizes();
        var outerX = x + borders.horizontal;
        var outerY = y + borders.vertical;
        this.$config.width = outerX;
        this.$config.height = outerY;
      };

      ViewCell.prototype.setSize = function (x, y) {
        _super.prototype.setSize.call(this, x, y);

        if (!this.$preResize && this.$content) {
          if (!this.$initialized) {
            this.$initialized = true;
            var header = this.$view.childNodes[0];
            var content = this.$view.childNodes[1];
            if (!content) content = header;

            /*if(this.$content.$config){
              this.$content.$config.width = this.$lastSize.contentX;
              this.$content.$config.height = this.$lastSize.contentY;
            }*/
            this.$content.init(content);
          }
        }
      };

      ViewCell.prototype.setContentSize = function () {
        if (!this.$preResize && this.$content) {
          if (this.$initialized) {
            this.$content.setSize(this.$lastSize.contentX, this.$lastSize.contentY);
          }
        }
      };


      ViewCell.prototype.getContentSize = function () {
        var size = _super.prototype.getContentSize.call(this);

        if (this.$content && this.$initialized) {
          var childSize = this.$content.getSize();
          size.width = childSize.contentX === undefined ? childSize.width : childSize.contentX;
          size.height = childSize.contentY === undefined ? childSize.height : childSize.contentY;
        }

        var borders = this._getBorderSizes();
        size.width += borders.horizontal;
        size.height += borders.vertical;

        return size;
      };

      return ViewCell;
    }(Cell));

   return ViewCell;

    /***/
  }

  viewLayout() {

    var __extends = this.utilsService.extends(),
      Layout = this.layout(),
      Cell = this.cell();

    var ViewLayout = (function (_super) {
      "use strict";

      __extends(ViewLayout, _super);
      function ViewLayout(parent, config, factory) {
        var _this = _super.apply(this, arguments) || this;
        for (var i = 0; i < _this.$cells.length; i++) {
          _this.$cells[i].$config.hidden = (i !== 0);
        }
        _this.$cell = _this.$cells[0];
        _this.$name = "viewLayout";

        return _this;
      }
      ViewLayout.prototype.cell = function (id) {
        var cell = _super.prototype.cell.call(this, id);
        if (!cell.$view) {
          this.$fill(null, this);
        }
        return cell;
      };
      ViewLayout.prototype.moveView = function (view) {
        var body = this.$view;
        if (this.$cell) {
          this.$cell.$config.hidden = true;
          body.removeChild(this.$cell.$view);
        }
        this.$cell = view;
        body.appendChild(view.$view);
      };
      ViewLayout.prototype.setSize = function (x, y) {
        Cell.prototype.setSize.call(this, x, y);
      };

      ViewLayout.prototype.setContentSize = function () {
        var size = this.$lastSize;
        this.$cell.setSize(size.contentX, size.contentY);
      };

      ViewLayout.prototype.getSize = function () {
        var sizes = _super.prototype.getSize.call(this);
        if (this.$cell) {
          var cellSize = this.$cell.getSize();
          if (this.$config.byMaxSize) {
            for (var i = 0; i < this.$cells.length; i++) {
              var otherCell = this.$cells[i].getSize();
              for (var cell in cellSize) {
                cellSize[cell] = Math.max(cellSize[cell], otherCell[cell]);
              }
            }
          }
          for (var size in sizes) {
            sizes[size] = sizes[size] || cellSize[size];
          }
          sizes.gravity = Math.max(sizes.gravity, cellSize.gravity);
        }
        return sizes;
      };
      return ViewLayout;
    }(Layout));

    return ViewLayout;

    /***/
  }
  
}
