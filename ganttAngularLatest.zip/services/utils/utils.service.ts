import { Injectable } from '@angular/core';
import { Promise } from '../../../../node_modules/bluebird/js/browser/bluebird.js';

@Injectable({
  providedIn: 'root'
})
export class UtilsService {
  units: any = {
    "second": 1,
    "minute": 60,
    "hour": 60 * 60,
    "day": 60 * 60 * 24,
    "week": 60 * 60 * 24 * 7,
    "month": 60 * 60 * 24 * 30,
    "quarter": 60 * 60 * 24 * 30 * 3,
    "year": 60 * 60 * 24 * 365
  }
  window:any;
  constructor() { }

  helpers: any = {

    getSecondsInUnit(unit) {
      return this.units[unit] || this.units.hour;
    },

    forEach(arr, callback) {
      if (arr.forEach) {
        arr.forEach(callback);
      } else {
        var workArray = arr.slice();
        for (var i = 0; i < workArray.length; i++) {
          callback(workArray[i], i);
        }
      }
    },

    arrayMap(arr, callback) {
      if (arr.map) {
        return arr.map(callback);
      } else {
        var workArray = arr.slice();
        var resArray = [];

        for (var i = 0; i < workArray.length; i++) {
          resArray.push(callback(workArray[i], i));
        }
        return resArray;
      }
    },

    arrayFind(arr, callback) {
      if (arr.find) {
        return arr.find(callback);
      } else {
        for (var i = 0; i < arr.length; i++) {
          if (callback(arr[i], i)) {
            return arr[i];
          }
        }
      }
    },

    // iframe-safe array type check instead of using instanceof
    isArray(obj) {
      if (Array.isArray) {
        return Array.isArray(obj);
      } else {
        // close enough
        return (obj && obj.length !== undefined && obj.pop && obj.push);
      }
    },

    // non-primitive string object, e.g. new String("abc")
    isStringObject(obj) {
      return obj && typeof obj === "object"
        && Function.prototype.toString.call(obj.constructor) === "function String() { [native code] }";
    },

    // non-primitive number object, e.g. new Number(5)
    isNumberObject(obj) {
      return obj && typeof obj === "object"
        && Function.prototype.toString.call(obj.constructor) === "function Number() { [native code] }";
    },

    // non-primitive number object, e.g. new Boolean(true)
    isBooleanObject(obj) {
      return obj && typeof obj === "object"
        && Function.prototype.toString.call(obj.constructor) === "function Boolean() { [native code] }";
    },

    isDate(obj) {
      if (obj && typeof obj === "object") {
        return !!(obj.getFullYear && obj.getMonth && obj.getDate);
      } else {
        return false;
      }
    },

    arrayFilter(arr, callback) {
      var result = [];

      if (arr.filter) {
        return arr.filter(callback);
      } else {
        for (var i = 0; i < arr.length; i++) {
          if (callback(arr[i], i)) {
            result[result.length] = arr[i];
          }
        }
        return result;
      }
    },

    hashToArray(hash) {
      var result = [];

      for (var key in hash) {
        if (hash.hasOwnProperty(key)) {
          result.push(hash[key]);
        }
      }

      return result;
    },

    arraySome(arr, callback) {
      if (arr.length === 0) return false;

      for (var i = 0; i < arr.length; i++) {
        if (callback(arr[i], i, arr)) {
          return true;
        }
      }
      return false;
    },

    arrayDifference(arr, callback) {
      return this.arrayFilter(arr, function (item, i) {
        return !callback(item, i);
      });
    },

    throttle(callback, timeout) {
      var wait = false;

      return function () {
        if (!wait) {
          callback.apply(null, arguments);
          wait = true;
          setTimeout(function () {
            wait = false;
          }, timeout);
        }
      };
    },

    delay(callback, timeout) {
      var timer;

      var result: any = function () {
        result.$cancelTimeout();
        callback.$pending = true;
        var args = Array.prototype.slice.call(arguments);
        timer = setTimeout(function () {
          callback.apply(this, args);
          result.$pending = false;
        }, timeout);
      };

      result.$pending = false;
      result.$cancelTimeout = function () {
        clearTimeout(timer);
        callback.$pending = false;
      };
      result.$execute = function () {
        callback();
        callback.$cancelTimeout();
      };

      return result;
    },

    sortArrayOfHash(arr, field, desc) {
      var compare = function (a, b) {
        return a < b;
      };

      arr.sort(function (a, b) {
        if (a[field] === b[field]) return 0;

        return desc ? compare(a[field], b[field]) : compare(b[field], a[field]);
      });
    },

    objectKeys(obj) {
      if (Object.keys) {
        return Object.keys(obj);
      }
      var result = [];
      var key;
      for (key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
          result.push(key);
        }
      }
      return result;
    },

    requestAnimationFrame(callback) {
      var w: any = window;
      var foundRequestAnimationFrame = w.requestAnimationFrame
        || w.webkitRequestAnimationFrame
        || w.msRequestAnimationFrame
        || w.mozRequestAnimationFrame
        || w.oRequestAnimationFrame
        || function (cb) { setTimeout(cb, 1000 / 60); };
      return foundRequestAnimationFrame(callback);
    },

    isEventable(obj) {
      return obj.attachEvent && obj.detachEvent;
    }
  }

  domEventScope() {

    var utils = this.utils();

    function createScope(addEvent, removeEvent) {
      addEvent = addEvent || utils.event;
      removeEvent = removeEvent || utils.eventRemove;

      var handlers = [];

      var eventScope = {
        attach(el, event, callback, capture) {
          handlers.push({ element: el, event: event, callback: callback, capture: capture });
          addEvent(el, event, callback, capture);
        },
        detach(el, event, callback, capture) {
          removeEvent(el, event, callback, capture);
          for (var i = 0; i < handlers.length; i++) {
            var handler = handlers[i];
            if (handler.element === el && handler.event === event && handler.callback === callback && handler.capture === capture) {
              handlers.splice(i, 1);
              i--;
            }
          }
        },
        detachAll() {
          var staticArray = handlers.slice();
          // original handlers array can be spliced on every iteration
          for (var i = 0; i < staticArray.length; i++) {
            var handler = staticArray[i];
            eventScope.detach(handler.element, handler.event, handler.callback, handler.capture);
            eventScope.detach(handler.element, handler.event, handler.callback, undefined);
            eventScope.detach(handler.element, handler.event, handler.callback, false);
            eventScope.detach(handler.element, handler.event, handler.callback, true);
          }
          handlers.splice(0, handlers.length);
        },
        extend() {
          return createScope(this.event, this.eventRemove);
        }
      };
      var w: any = window
      if (!w.scopes) {
        w.scopes = [];
      }
      w.scopes.push(handlers);
      return eventScope;
    }

    return createScope;

    /***/
  }

  domHelpers() {

    //returns position of html element on the page
    function elementPosition(elem) {
      var top = 0, left = 0, right = 0, bottom = 0;
      if (elem.getBoundingClientRect) { //HTML5 method
        var box = elem.getBoundingClientRect();
        var body = document.body;
        var docElem: any = (document.documentElement ||
          document.body.parentNode ||
          document.body);

        var scrollTop = window.pageYOffset || docElem.scrollTop || body.scrollTop;
        var scrollLeft = window.pageXOffset || docElem.scrollLeft || body.scrollLeft;
        var clientTop = docElem.clientTop || body.clientTop || 0;
        var clientLeft = docElem.clientLeft || body.clientLeft || 0;
        top = box.top + scrollTop - clientTop;
        left = box.left + scrollLeft - clientLeft;

        right = document.body.offsetWidth - box.right;
        bottom = document.body.offsetHeight - box.bottom;
      } else { //fallback to naive approach
        while (elem) {
          top = top + parseInt(elem.offsetTop, 10);
          left = left + parseInt(elem.offsetLeft, 10);
          elem = elem.offsetParent;
        }

        right = document.body.offsetWidth - elem.offsetWidth - left;
        bottom = document.body.offsetHeight - elem.offsetHeight - top;
      }
      return { y: Math.round(top), x: Math.round(left), width: elem.offsetWidth, height: elem.offsetHeight, right: Math.round(right), bottom: Math.round(bottom) };
    }

    function isVisible(node) {
      var display: any = false,
        visibility: any = false;
      if (window.getComputedStyle) {
        var style = window.getComputedStyle(node, null);
        display = style["display"];
        visibility = style["visibility"];
      } else if (node.currentStyle) {
        display = node.currentStyle["display"];
        visibility = node.currentStyle["visibility"];
      }
      return (display != "none" && visibility != "hidden");
    }

    function hasNonNegativeTabIndex(node) {
      return !isNaN(node.getAttribute("tabindex")) && (node.getAttribute("tabindex") * 1 >= 0);
    }

    function hasHref(node) {
      var canHaveHref = { "a": true, "area": true };
      if (canHaveHref[node.nodeName.loLowerCase()]) {
        return !!node.getAttribute("href");
      }
      return true;
    }

    function isEnabled(node) {
      var canDisable = { "input": true, "select": true, "textarea": true, "button": true, "object": true };
      if (canDisable[node.nodeName.toLowerCase()]) {
        return !node.hasAttribute("disabled");
      }

      return true;
    }

    function getFocusableNodes(root) {
      var nodes = root.querySelectorAll([
        "a[href]",
        "area[href]",
        "input",
        "select",
        "textarea",
        "button",
        "iframe",
        "object",
        "embed",
        "[tabindex]",
        "[contenteditable]"
      ].join(", "));

      var nodesArray = Array.prototype.slice.call(nodes, 0);
      for (var i = 0; i < nodesArray.length; i++) {
        var node = nodesArray[i];
        var isValid = (hasNonNegativeTabIndex(node) || isEnabled(node) || hasHref(node)) && isVisible(node);
        if (!isValid) {
          nodesArray.splice(i, 1);
          i--;
        }
      }
      return nodesArray;
    }

    function getScrollSize() {
      var div = document.createElement("div");
      div.style.cssText = "visibility:hidden;position:absolute;left:-1000px;width:100px;padding:0px;margin:0px;height:110px;min-height:100px;overflow-y:scroll;";

      document.body.appendChild(div);
      var width = div.offsetWidth - div.clientWidth;
      document.body.removeChild(div);

      return width;
    }

    function getClassName(node) {
      if (!node) return "";

      var className = node.className || "";
      if (className.baseVal)//'className' exist but not a string - IE svg element in DOM
        className = className.baseVal;

      if (!className.indexOf)
        className = "";

      return _trimString(className);
    }

    function addClassName(node, className) {
      if (className && node.className.indexOf(className) === -1) {
        node.className += " " + className;
      }
    }

    function removeClassName(node, name) {
      name = name.split(" ");
      for (var i = 0; i < name.length; i++) {
        var regEx = new RegExp("\\s?\\b" + name[i] + "\\b(?![-_.])", "");
        node.className = node.className.replace(regEx, "");
      }
    }

    function hasClass(element, className) {
      if ('classList' in element) {
        return element.classList.contains(className);
      } else {
        return new RegExp("\\b" + className + "\\b").test(element.className);
      }
    }

    function toNode(node) {
      if (typeof node === "string") {
        return (document.getElementById(node) || document.querySelector(node) || document.body);
      }
      return node || document.body;
    }

    var _slave = document.createElement("div");
    function insert(node, newone) {
      _slave.innerHTML = newone;
      var child = _slave.firstChild;
      node.appendChild(child);
      return child;
    }

    function remove(node) {
      if (node && node.parentNode) {
        node.parentNode.removeChild(node);
      }
    }

    function getChildren(node, css) {
      var ch = node.childNodes;
      var len = ch.length;
      var out = [];
      for (var i = 0; i < len; i++) {
        var obj = ch[i];
        if (obj.className && obj.className.indexOf(css) !== -1) {
          out.push(obj);
        }
      }
      return out;
    }

    function getTargetNode(e) {
      var trg;
      if (e.tagName)
        trg = e;
      else {
        e = e || window.event;
        trg = e.target || e.srcElement;
      }
      return trg;
    }

    function locateAttribute(e, attribute) {
      if (!attribute) return;

      var trg = getTargetNode(e);

      while (trg) {
        if (trg.getAttribute) {	//text nodes has not getAttribute
          var test = trg.getAttribute(attribute);
          if (test) return trg;
        }
        trg = trg.parentNode;
      }
      return null;
    }

    function _trimString(str) {
      var func = String.prototype.trim || function () { return this.replace(/^\s+|\s+$/g, ""); };
      return func.apply(str);
    }

    function locateClassName(e, classname, strict?) {
      var trg = getTargetNode(e);
      var css = "";

      if (strict === undefined)
        strict = true;

      while (trg) {
        css = getClassName(trg);
        if (css) {
          var ind = css.indexOf(classname);
          if (ind >= 0) {
            if (!strict)
              return trg;

            //check that we have exact match
            var left = (ind === 0) || (!_trimString(css.charAt(ind - 1)));
            var right = ((ind + classname.length >= css.length)) || (!_trimString(css.charAt(ind + classname.length)));

            if (left && right)
              return trg;
          }
        }
        trg = trg.parentNode;
      }
      return null;
    }

    /*
    event position relatively to DOM element
     */
    function getRelativeEventPosition(ev, node) {
      var d = document.documentElement;
      var box = elementPosition(node);

      return {
        x: ev.clientX + d.scrollLeft - d.clientLeft - box.x + node.scrollLeft,
        y: ev.clientY + d.scrollTop - d.clientTop - box.y + node.scrollTop
      };
    }

    function isChildOf(child, parent) {
      if (!child || !parent) {
        return false;
      }

      while (child && child != parent) {
        child = child.parentNode;
      }

      return child === parent;
    }

    function closest(element, selector) {
      if (element.closest) {
        return element.closest(selector);
      } else if (element.matches || element.msMatchesSelector || element.webkitMatchesSelector) {
        var el = element;
        if (!document.documentElement.contains(el)) return null;
        do {
          var method = el.matches || el.msMatchesSelector || el.webkitMatchesSelector;

          if (method.call(el, selector)) return el;
          el = el.parentElement || el.parentNode;
        } while (el !== null && el.nodeType === 1);
        return null;
      } else {
        // eslint-disable-next-line no-console
        console.error("Your browser is not supported");
        return null;
      }
    }

    return {
      getNodePosition: elementPosition,
      getFocusableNodes: getFocusableNodes,
      getScrollSize: getScrollSize,
      getClassName: getClassName,
      addClassName: addClassName,
      removeClassName: removeClassName,
      insertNode: insert,
      removeNode: remove,
      getChildNodes: getChildren,
      toNode: toNode,
      locateClassName: locateClassName,
      locateAttribute: locateAttribute,
      getTargetNode: getTargetNode,
      getRelativeEventPosition: getRelativeEventPosition,
      isChildOf: isChildOf,
      hasClass: hasClass,
      closest: closest
    };

    /***/
  }

  env() {

    var env = {
      isIE: (navigator.userAgent.indexOf("MSIE") >= 0 || navigator.userAgent.indexOf("Trident") >= 0),
      isIE6: (!this.window.XMLHttpRequest && navigator.userAgent.indexOf("MSIE") >= 0),
      isIE7: (navigator.userAgent.indexOf("MSIE 7.0") >= 0 && navigator.userAgent.indexOf("Trident") < 0),
      isIE8: (navigator.userAgent.indexOf("MSIE 8.0") >= 0 && navigator.userAgent.indexOf("Trident") >= 0),
      isOpera: (navigator.userAgent.indexOf("Opera") >= 0),
      isChrome: (navigator.userAgent.indexOf("Chrome") >= 0),
      isKHTML: (navigator.userAgent.indexOf("Safari") >= 0 || navigator.userAgent.indexOf("Konqueror") >= 0),
      isFF: (navigator.userAgent.indexOf("Firefox") >= 0),
      isIPad: (navigator.userAgent.search(/iPad/gi) >= 0),
      isEdge: (navigator.userAgent.indexOf("Edge") != -1)
    };

    return env;

  }

  eventable() {

    var EventHost = function () {
      this._connected = [];
      this._silent_mode = false;
    };

    EventHost.prototype = {
      _silentStart: function () {
        this._silent_mode = true;
      },
      _silentEnd: function () {
        this._silent_mode = false;
      }
    };

    var createEventStorage = function (obj) {
      var dhx_catch = [];
      var z: any = function () {
        var res = true;
        for (var i = 0; i < dhx_catch.length; i++) {
          if (dhx_catch[i]) {
            var zr = dhx_catch[i].apply(obj, arguments);
            res = res && zr;
          }
        }
        return res;
      };
      z.addEvent = function (ev) {
        if (typeof (ev) == "function")
          return dhx_catch.push(ev) - 1;
        return false;
      };
      z.removeEvent = function (id) {
        dhx_catch[id] = null;
      };
      return z;
    };

    function makeEventable(obj) {

      var eventHost = new EventHost();
      obj.attachEvent = function (name, catcher, callObj) {
        name = 'ev_' + name.toLowerCase();
        if (!eventHost[name])
          eventHost[name] = createEventStorage(callObj || this);

        return (name + ':' + eventHost[name].addEvent(catcher)); //return ID (event name & event ID)
      };
      obj.attachAll = function (callback, callObj) {
        this.attachEvent('listen_all', callback, callObj);
      };

      obj.callEvent = function (name, arg0, callObj) {
        if (eventHost._silent_mode) return true;

        var handlerName = 'ev_' + name.toLowerCase();

        if (eventHost['ev_listen_all']) {
          eventHost['ev_listen_all'].apply(callObj || this, [name].concat(arg0));
        }

        if (eventHost[handlerName])
          return eventHost[handlerName].apply(callObj || this, arg0);
        return true;
      };
      obj.checkEvent = function (name) {
        return (!!eventHost['ev_' + name.toLowerCase()]);
      };
      obj.detachEvent = function (id) {
        if (id) {
          var list = id.split(':');//get EventName and ID
          var eventName = list[0];
          var eventId = list[1];

          if (eventHost[eventName]) {
            eventHost[eventName].removeEvent(eventId); //remove event
          }
        }
      };
      obj.detachAllEvents = function () {
        for (var name in eventHost) {
          if (name.indexOf("ev_") === 0)
            delete eventHost[name];
        }
      };

    }

    return makeEventable;

    /***/
  }

  extends() {

  return function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };

  /***/
  }

  htmlHelpers() {

    var helpers = this.helpers;

    var htmlHelpers = {
      getHtmlSelect: function (options, attributes, value?) {
        var innerHTML = "";
        var _this = this;

        options = options || [];

        helpers.forEach(options, function (entry) {
          var _attributes = [{ key: "value", value: entry.key }];

          if (value == entry.key) {
            _attributes[_attributes.length] = { key: "selected", value: "selected" };
          }
          if (entry.attributes) {
            _attributes = _attributes.concat(entry.attributes);
          }
          innerHTML += _this.getHtmlOption({ innerHTML: entry.label }, _attributes);
        });

        return _getHtmlContainer("select", { innerHTML: innerHTML }, attributes);
      },
      getHtmlOption: function (options, attributes) { return _getHtmlContainer("option", options, attributes); },
      getHtmlButton: function (options, attributes) { return _getHtmlContainer("button", options, attributes); },
      getHtmlDiv: function (options, attributes) { return _getHtmlContainer("div", options, attributes); },
      getHtmlLabel: function (options, attributes) { return _getHtmlContainer("label", options, attributes); },
      getHtmlInput: function (attributes) {
        return "<input" + _getHtmlAttributes(attributes || []) + ">";
      }
    };

    function _getHtmlContainer(tag, options, attributes) {
      var html;

      options = options || [];

      html = "<" + tag + _getHtmlAttributes(attributes || []) + ">" + (options.innerHTML || "") + "</" + tag + ">";
      return html;

    }

    function _getHtmlAttributes(attributes) {
      var html = "";

      helpers.forEach(attributes, function (entry) {
        html += " " + entry.key + "='" + entry.value + "'";
      });
      return html;
    }

    return htmlHelpers;

    /***/
  }

  promise() {

    return Promise;

    /***/
  }

  taskTreeHelpers() {

    function copyLinkIdsArray(gantt, linkIds, targetHash) {
      for (var i = 0; i < linkIds.length; i++) {
        if (gantt.isLinkExists(linkIds[i])) {
          targetHash[linkIds[i]] = gantt.getLink(linkIds[i]);
        }
      }
    }

    function copyLinkIds(gantt, task, targetHash) {
      copyLinkIdsArray(gantt, task.$source, targetHash);
      copyLinkIdsArray(gantt, task.$target, targetHash);
    }

    function getSubtreeLinks(gantt, rootId) {
      var res = {};

      if (gantt.isTaskExists(rootId)) {
        copyLinkIds(gantt, gantt.getTask(rootId), res);
      }

      gantt.eachTask(function (child) {
        copyLinkIds(gantt, child, res);
      }, rootId);

      return res;
    }

    function getSubtreeTasks(gantt, rootId) {
      var res = {};

      gantt.eachTask(function (child) {
        res[child.id] = child;
      }, rootId);

      return res;
    }

    return {
      getSubtreeLinks: getSubtreeLinks,
      getSubtreeTasks: getSubtreeTasks
    };

    /***/
  }

  timeout() {

    function checkTimeout(host, updPerSecond) {
      if (!updPerSecond)
        return true;

      if (host._on_timeout)
        return false;

      var timeout = Math.ceil(1000 / updPerSecond);
      if (timeout < 2) return true;

      setTimeout(function () {
        delete host._on_timeout;
      }, timeout);

      host._on_timeout = true;
      return true;
    }

    return checkTimeout;

    /***/
  }

  utils() {

    var helpers = this.helpers;

    function copy(object) {
      var i, result; // iterator, types array, result

      if (object && typeof object == "object") {

        switch (true) {
          case (helpers.isDate(object)):
            result = new Date(object);
            break;
          case (helpers.isArray(object)):
            result = new Array(object.length);
            for (i = 0; i < object.length; i++) {
              result[i] = copy(object[i]);
            }
            break;
          case (helpers.isStringObject(object)):
            result = new String(object);
            break;
          case (helpers.isNumberObject(object)):
            result = new Number(object);
            break;
          case (helpers.isBooleanObject(object)):
            result = new Boolean(object);
            break;
          default:
            result = {};
            for (i in object) {
              if (Object.prototype.hasOwnProperty.apply(object, [i]))
                result[i] = copy(object[i]);
            }
            break;
        }
      }
      return result || object;
    }

    function mixin(target, source, force?) {
      for (var f in source)
        if (((target[f] === undefined) || force)) target[f] = source[f];
      return target;
    }

    function defined(obj) {
      return typeof (obj) != "undefined";
    }

    var seed;
    function uid() {
      if (!seed)
        seed = (new Date()).valueOf();

      seed++;
      return seed;
    }

    //creates function with specified "this" pointer
    function bind(functor, object) {
      if (functor.bind)
        return functor.bind(object);
      else
        return function () { return functor.apply(object, arguments); };
    }

    function event(el, event, handler, capture) {
      if (el.addEventListener)
        el.addEventListener(event, handler, capture === undefined ? false : capture);

      else if (el.attachEvent)
        el.attachEvent("on" + event, handler);
    }

    function eventRemove(el, event, handler, capture) {
      if (el.removeEventListener)
        el.removeEventListener(event, handler, capture === undefined ? false : capture);

      else if (el.detachEvent)
        el.detachEvent("on" + event, handler);
    }

    return {
      copy: copy,
      defined: defined,
      mixin: mixin,
      uid: uid,
      bind: bind,
      event: event,
      eventRemove: eventRemove
    };

    /***/
  }
}
