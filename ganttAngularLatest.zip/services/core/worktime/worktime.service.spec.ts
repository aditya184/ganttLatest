import { TestBed } from '@angular/core/testing';

import { WorktimeService } from './worktime.service';

describe('WorktimeService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WorktimeService = TestBed.get(WorktimeService);
    expect(service).toBeTruthy();
  });
});
