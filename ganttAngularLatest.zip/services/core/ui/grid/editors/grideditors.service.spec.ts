import { TestBed } from '@angular/core/testing';

import { GridEditorsService } from './grideditors.service';

describe('EditorsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GridEditorsService = TestBed.get(GridEditorsService);
    expect(service).toBeTruthy();
  });
});
