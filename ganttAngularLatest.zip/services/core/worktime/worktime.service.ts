import { Injectable } from '@angular/core';
import { FacadesService } from '../facades/facades.service';
import { UtilsService } from '../../utils/utils.service';
import { StrategyService } from './strategy/strategy.service';

@Injectable({
  providedIn: 'root'
})
export class WorktimeService {

  constructor(private facadeService: FacadesService, private utilsService: UtilsService, private startegyService: StrategyService) { }

  calendarArgumentsHelper() {

    var utils = this.utilsService.utils();
    var helpers = this.utilsService.helpers;


    function IsWorkTimeArgument(date, unit, task, id, calendar) {
      this.date = date;
      this.unit = unit;
      this.task = task;
      this.id = id;
      this.calendar = calendar;
      return this;
    }

    function ClosestWorkTimeArgument(date, dir?, unit?, task?, id?, calendar?) {
      this.date = date;
      this.dir = dir;
      this.unit = unit;
      this.task = task;
      this.id = id;
      this.calendar = calendar;
      return this;
    }

    function CalculateEndDateArgument(start_date, duration, unit, step, task, id, calendar) {
      this.start_date = start_date;
      this.duration = duration;
      this.unit = unit;
      this.step = step;
      this.task = task;
      this.id = id;
      this.calendar = calendar;
      return this;
    }

    function GetDurationArgument(start, end, task, calendar) {
      this.start_date = start;
      this.end_date = end;
      this.task = task;
      this.calendar = calendar;
      this.unit = null;
      this.step = null;
      return this;
    }

    var calendarArgumentsHelper = function (gantt) {
      return {
        getWorkHoursArguments: function () {
          var config = arguments[0];
          if (helpers.isDate(config)) {
            config = {
              date: config
            };
          } else {
            config = utils.mixin({}, config);
          }
          return config;
        },
        setWorkTimeArguments: function () {
          return arguments[0];
        },
        unsetWorkTimeArguments: function () {
          return arguments[0];
        },
        isWorkTimeArguments: function () {
          var config = arguments[0];
          if (config instanceof IsWorkTimeArgument) {
            return config;
          }

          var processedConfig;
          if (!config.date) {
            //IsWorkTimeArgument(date, unit, task, id, calendar)
            processedConfig = IsWorkTimeArgument(arguments[0], arguments[1], arguments[2], null, arguments[3]);
          } else {
            processedConfig = IsWorkTimeArgument(config.date, config.unit, config.task, null, config.calendar);
          }

          processedConfig.unit = processedConfig.unit || gantt.config.duration_unit;

          return processedConfig;
        },
        getClosestWorkTimeArguments: function (arg) {
          var config = arguments[0];
          if (config instanceof ClosestWorkTimeArgument)
            return config;

          var processedConfig;
          if (helpers.isDate(config)) {
            // processedConfig = ClosestWorkTimeArgument(config);
            processedConfig = ClosestWorkTimeArgument(config);
          } else {
            processedConfig = ClosestWorkTimeArgument(
              config.date,
              config.dir,
              config.unit,
              config.task,
              null,//config.id,
              config.calendar
            );
          }

          if (config.id) {
            processedConfig.task = config;
          }
          processedConfig.dir = config.dir || 'any';
          processedConfig.unit = config.unit || gantt.config.duration_unit;

          return processedConfig;
        },

        _getStartEndConfig: function (param) {
          var argumentType = GetDurationArgument;
          var config;
          if (param instanceof argumentType)
            return param;

          if (helpers.isDate(param)) {
            config = argumentType(arguments[0], arguments[1], arguments[2], arguments[3]);
          } else {
            config = argumentType(param.start_date, param.end_date, param.task, null);
            if (param.id) {
              config.task = param;
            }
          }

          config.unit = config.unit || gantt.config.duration_unit;
          config.step = config.step || gantt.config.duration_step;
          config.start_date = config.start_date || config.start || config.date;

          return config;
        },

        getDurationArguments: function (start, end, unit, step) {
          return this._getStartEndConfig.apply(this, arguments);
        },

        hasDurationArguments: function (start, end, unit, step) {
          return this._getStartEndConfig.apply(this, arguments);
        },

        calculateEndDateArguments: function (start, duration, unit, step) {
          var config = arguments[0];
          if (config instanceof CalculateEndDateArgument)
            return config;

          var processedConfig;
          //CalculateEndDateArgument(start_date, duration, unit, step, task, id, calendar)
          if (helpers.isDate(config)) {
            processedConfig = CalculateEndDateArgument(
              arguments[0],
              arguments[1],
              arguments[2],
              undefined,
              arguments[3],
              undefined,
              arguments[4]
            );

          } else {
            processedConfig = CalculateEndDateArgument(
              config.start_date,
              config.duration,
              config.unit,
              config.step,
              config.task,
              null,//config.id,
              config.calendar
            );
          }
          if (config.id) {
            processedConfig.task = config;
          }

          processedConfig.unit = processedConfig.unit || gantt.config.duration_unit;
          processedConfig.step = processedConfig.step || gantt.config.duration_step;

          return processedConfig;
        }
      };
    };


    return calendarArgumentsHelper;

    /***/
  }

  calendarManager() {

    var utils = this.utilsService.utils();
    var createArgumentsHelper = this.calendarArgumentsHelper();
    var CalendarWorktimeStrategy = this.startegyService.calendarStrategy();

    function CalendarManager(gantt) {
      this.$gantt = gantt;
      this._calendars = {};
    }

    CalendarManager.prototype = {
      _calendars: {},
      _getDayHoursForMultiple: function (calendars, date) {
        var units: any = [],
          tick = true,
          currPos = 0,
          is_work_hour = false,
          start = this.$gantt.date.day_start(new Date(date));
        for (var hour = 0; hour < 24; hour++) {
          is_work_hour = calendars.reduce(function (acc, calendar) {
            return acc && calendar._is_work_hour(start);
          }, true);
          if (is_work_hour) {
            if (tick) {
              units[currPos] = hour;
              units[currPos + 1] = (hour + 1);
              currPos += 2;
            } else {
              units[currPos - 1] += 1;
            }
            tick = false;
          } else if (!tick) {
            tick = true;
          }
          start = this.$gantt.date.add(start, 1, "hour");
        }
        if (!units.length)
          units = false;
        return units;
      },
      mergeCalendars: function () {
        var newCalendar = this.createCalendar(),
          day,
          units = [];
        var calendars = Array.prototype.slice.call(arguments, 0);
        newCalendar.worktime.hours = [0, 24];
        newCalendar.worktime.dates = {};
        var start = this.$gantt.date.day_start(new Date(259200000)); // 1970 day=0
        for (day = 0; day < 7; day++) {
          units = this._getDayHoursForMultiple(calendars, start);
          newCalendar.worktime.dates[day] = units;
          start = this.$gantt.date.add(start, 1, "day");
        }
        for (var i = 0; i < calendars.length; i++) {
          for (var value in calendars[i].worktime.dates) if (+value > 10000) {
            units = this._getDayHoursForMultiple(calendars, new Date(+value));
            newCalendar.worktime.dates[value] = units;
          }
        }
        return newCalendar;
      },

      _convertWorktimeSettings: function (settings) {
        var days = settings.days;
        if (days) {
          settings.dates = settings.dates || {};
          for (var i = 0; i < days.length; i++) {
            settings.dates[i] = days[i];
            if (!(days[i] instanceof Array)) {
              settings.dates[i] = !!days[i];
            }
          }
          delete settings.days;
        }
        return settings;
      },

      createCalendar: function (parentCalendar) {
        var settings;

        if (!parentCalendar) {
          parentCalendar = {};
        }

        if (parentCalendar.worktime) {
          settings = utils.copy(parentCalendar.worktime);
        } else {
          settings = utils.copy(parentCalendar);
        }

        var defaults = utils.copy(this.defaults.fulltime.worktime);
        utils.mixin(settings, defaults);

        var id = utils.uid();
        var calendar = {
          id: id + "",
          worktime: this._convertWorktimeSettings(settings)
        };

        var apiCore = new CalendarWorktimeStrategy(this.$gantt, createArgumentsHelper(this.$gantt));
        utils.mixin(apiCore, calendar);

        // validate/check if empty calendar
        if (!apiCore._tryChangeCalendarSettings(function () {
        })) {
          return null;
        } else {
          return apiCore;
        }
      },

      getCalendar: function (id) {
        id = id || "global";
        this.createDefaultCalendars();
        return this._calendars[id];
      },

      getCalendars: function () {
        var res = [];
        for (var i in this._calendars) {
          res.push(this.getCalendar(i));
        }
        return res;
      },

      _getOwnCalendar: function (task) {
        var config = this.$gantt.config;
        if (task[config.calendar_property]) {
          return this.getCalendar(task[config.calendar_property]);
        }

        if (config.resource_calendars) {
          for (var field in config.resource_calendars) {
            var resource = config.resource_calendars[field];
            if (task[field]) {
              var calendarId = resource[task[field]];
              if (calendarId) {
                return this.getCalendar(calendarId);
              }
            }
          }
        }
        return null;
      },

      getTaskCalendar: function (task) {
        if (!task) {
          return this.getCalendar();
        }

        var calendar = this._getOwnCalendar(task);
        var gantt = this.$gantt;
        if (!calendar && gantt.config.inherit_calendar && gantt.isTaskExists(task.parent)) {
          var stop = false;
          gantt.eachParent(function (parent) {
            if (stop) return;
            if (gantt.isSummaryTask(parent)) {
              calendar = this._getOwnCalendar(parent);
              if (calendar) {
                stop = true;
              }
            }
          }, task.id, this);
        }

        return calendar || this.getCalendar();
      },

      addCalendar: function (calendar) { // puts new calendar to Global Storage - gantt.calendarManager._calendars {}
        if (!(calendar instanceof CalendarWorktimeStrategy)) {
          var id = calendar.id;
          calendar = this.createCalendar(calendar);
          calendar.id = id;
        }
        var config = this.$gantt.config;

        calendar.id = calendar.id || utils.uid();
        this._calendars[calendar.id] = calendar;
        if (!config.worktimes)
          config.worktimes = {};
        config.worktimes[calendar.id] = calendar.worktime;
        return calendar.id;
      },

      deleteCalendar: function (calendar) {
        var config = this.$gantt.config;
        if (!calendar) return false;
        if (this._calendars[calendar]) {
          delete this._calendars[calendar];
          if (config.worktimes && config.worktimes[calendar])
            delete config.worktimes[calendar];
          return true;
        } else {
          return false;
        }
      },

      restoreConfigCalendars: function (configs) {
        for (var i in configs) {
          if (this._calendars[i])
            continue;

          var settings = configs[i];
          var calendar = this.createCalendar(settings);
          calendar.id = i;
          this.addCalendar(calendar);
        }
      },

      defaults: {
        global: {
          id: "global",
          worktime: {
            hours: [8, 17],
            days: [0, 1, 1, 1, 1, 1, 0]
          }
        },
        fulltime: {
          id: "fulltime",
          worktime: {
            hours: [0, 24],
            days: [1, 1, 1, 1, 1, 1, 1]
          }
        }
      },

      createDefaultCalendars: function () {
        var config = this.$gantt.config;
        this.restoreConfigCalendars(this.defaults);
        this.restoreConfigCalendars(config.worktimes);
      }
    };

    return CalendarManager;

    /***/
  }

  timeCalculator() {

    var createArgumentsHelper = this.calendarArgumentsHelper(),
      NoWorkTimeCalendar = this.startegyService.noWorkTime();

    function TimeCalculator(calendarManager) {

      this.$gantt = calendarManager.$gantt;
      this.argumentsHelper = createArgumentsHelper(this.$gantt);
      this.calendarManager = calendarManager;
      this.$disabledCalendar = new NoWorkTimeCalendar(this.$gantt, this.argumentsHelper);
    }

    TimeCalculator.prototype = {
      _getCalendar: function (config) {
        var calendar;
        if (!this.$gantt.$services.config().work_time) {
          calendar = this.$disabledCalendar;
        } else {
          var manager = this.calendarManager;
          if (config.task) {
            calendar = manager.getTaskCalendar(config.task);
          } else if (config.id) {
            calendar = manager.getTaskCalendar(config);
          } else if (config.calendar) {
            calendar = config.calendar;
          }
          if (!calendar) {
            calendar = manager.getTaskCalendar();
          }
        }
        return calendar;
      },

      getWorkHours: function (config) {
        config = this.argumentsHelper.getWorkHoursArguments.apply(this.argumentsHelper, arguments);

        var calendar = this._getCalendar(config);

        return calendar.getWorkHours(config.date);
      },

      setWorkTime: function (config, calendar) {
        config = this.argumentsHelper.setWorkTimeArguments.apply(this.argumentsHelper, arguments);

        if (!calendar)
          calendar = this.calendarManager.getCalendar(); // Global
        return calendar.setWorkTime(config);
      },

      unsetWorkTime: function (config, calendar) {
        config = this.argumentsHelper.unsetWorkTimeArguments.apply(this.argumentsHelper, arguments);

        if (!calendar)
          calendar = this.calendarManager.getCalendar(); // Global
        return calendar.unsetWorkTime(config);
      },
      isWorkTime: function (date, unit, task, calendar) {
        var config = this.argumentsHelper.isWorkTimeArguments.apply(this.argumentsHelper, arguments);

        calendar = this._getCalendar(config);
        return calendar.isWorkTime(config);
      },
      getClosestWorkTime: function (config) {
        config = this.argumentsHelper.getClosestWorkTimeArguments.apply(this.argumentsHelper, arguments);

        var calendar = this._getCalendar(config);

        return calendar.getClosestWorkTime(config);
      },

      calculateDuration: function () { // start_date_date, end_date, task
        var config = this.argumentsHelper.getDurationArguments.apply(this.argumentsHelper, arguments);


        var calendar = this._getCalendar(config);
        return calendar.calculateDuration(config);
      },
      hasDuration: function () {
        var config = this.argumentsHelper.hasDurationArguments.apply(this.argumentsHelper, arguments);

        var calendar = this._getCalendar(config);

        return calendar.hasDuration(config);
      },
      calculateEndDate: function (config) { // start_date, duration, unit, task
        var config = this.argumentsHelper.calculateEndDateArguments.apply(this.argumentsHelper, arguments);

        var calendar = this._getCalendar(config);
        return calendar.calculateEndDate(config);
      }
    };

    return TimeCalculator;



    /***/
  }

  // workTime() {

  workTime(gantt) {
    var CalendarManager = this.calendarManager(),
      TimeCalculator = this.timeCalculator(),
      worktimeFacadeFactory = this.facadeService.worktimeCalendars(),
      utils = this.utilsService.utils();
    var manager = new CalendarManager(gantt),
      timeCalculator = new TimeCalculator(manager);
    var facade = worktimeFacadeFactory.create(manager, timeCalculator);
    utils.mixin(gantt, facade);
  }


  /***/
  // }
}
