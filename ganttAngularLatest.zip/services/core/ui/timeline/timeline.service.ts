import { Injectable } from '@angular/core';
import { UtilsService } from 'src/app/services/utils/utils.service';
import { UiService } from '../ui.service';

@Injectable({
  providedIn: 'root'
})
export class TimelineService {

  constructor(private utilsService:UtilsService) { }

  linksDnd() {

    var domHelpers = this.utilsService.domHelpers();

    var initLinksDND = function (timeline, gantt) {
      var _link_landing,
        _link_target_task,
        _link_target_task_start,
        _link_source_task,
        _link_source_task_start,
        markerDefaultOffset = 10,
        scrollDefaultSize = 18;


      function getVisibleMilestoneWidth() {
        var origWidth = timeline.getItemHeight();//m-s have square shape
        return Math.round(Math.sqrt(2 * origWidth * origWidth)) - 2;
      }

      function isMilestone(task) {
        return gantt.getTaskType(task.type) == gantt.config.types.milestone;
      }

      function getDndState() {
        return {
          link_source_id: _link_source_task,
          link_target_id: _link_target_task,
          link_from_start: _link_source_task_start,
          link_to_start: _link_target_task_start,
          link_landing_area: _link_landing
        };
      }

      var services = gantt.$services;

      var state = services.getService("state");
      var DnD = services.getService("dnd");

      state.registerProvider("linksDnD", getDndState);

      var dnd = new DnD(timeline.$task_bars, { sensitivity: 0, updates_per_second: 60 }),
        start_marker = "task_start_date",
        end_marker = "task_end_date",
        link_edge_marker = "gantt_link_point",
        link_landing_hover_area = "gantt_link_control";

      dnd.attachEvent("onBeforeDragStart", gantt.bind(function (obj, e) {
        var target = (e.target || e.srcElement);
        resetDndState();
        if (gantt.getState().drag_id)
          return false;

        if (domHelpers.locateClassName(target, link_edge_marker)) {
          if (domHelpers.locateClassName(target, start_marker))
            _link_source_task_start = true;

          var sid = gantt.locate(e);
          _link_source_task = sid;

          var t = gantt.getTask(sid);
          if (gantt.isReadonly(t)) {
            resetDndState();
            return false;
          }

          var shift = 0;

          this._dir_start = getLinePos(t, !!_link_source_task_start, shift, timeline.$getConfig(), true);
          return true;
        } else {
          return false;
        }

      }, this));

      dnd.attachEvent("onAfterDragStart", gantt.bind(function (obj, e) {
        if (gantt.config.touch) {
          gantt.refreshData();
        }
        updateMarkedHtml(dnd.config.marker);
      }, this));

      function getLinePos(task, to_start, shift, cfg, isStart?) {
        var taskPos: any = getMilestonePosition(task, function (task) { return gantt.getTaskPosition(task); }, cfg);

        var pos: any = { x: taskPos.x, y: taskPos.y };
        if (!to_start) {
          pos.x = taskPos.xEnd;
        }

        //var pos = gantt._get_task_pos(task, !!to_start);
        pos.y += gantt.config.row_height / 2;

        var offset = isMilestone(task) && isStart ? 2 : 0;

        shift = shift || 0;
        if (cfg.rtl)
          shift = shift * -1;

        pos.x += (to_start ? -1 : 1) * shift - offset;
        return pos;
      }

      function getMilestonePosition(task, getTaskPosition, cfg) {
        var pos = getTaskPosition(task);

        var res: any = {
          x: pos.left,
          y: pos.top,
          width: pos.width,
          height: pos.height
        };

        if (cfg.rtl) {
          res.xEnd = res.x;
          res.x = res.xEnd + res.width;
        } else {
          res.xEnd = res.x + res.width;
        }
        res.yEnd = res.y + res.height;

        if (gantt.getTaskType(task.type) == gantt.config.types.milestone) {
          var milestoneWidth = getVisibleMilestoneWidth();

          res.x += (!cfg.rtl ? -1 : 1) * (milestoneWidth / 2);
          res.xEnd += (!cfg.rtl ? 1 : -1) * (milestoneWidth / 2);

          //pos.x -= milestoneWidth / 2;
          //pos.xEnd += milestoneWidth / 2;
          res.width = pos.xEnd - pos.x;
        }


        return res;
      }

      function getVieportSize() {
        var root = gantt.$root;
        return { right: root.offsetWidth, bottom: root.offsetHeight };
      }
      function getMarkerSize(marker) {
        var width = 0, height = 0;
        if (marker) {
          width = marker.offsetWidth || 0;
          height = marker.offsetHeight || 0;
        }
        return { width: width, height: height };
      }

      function getPosition(e, marker) {
        var oldPos = dnd.getPosition(e);

        var markerSize = getMarkerSize(marker);
        var viewportSize = getVieportSize();

        var offsetX = gantt.config.tooltip_offset_x || markerDefaultOffset;
        var offsetY = gantt.config.tooltip_offset_y || markerDefaultOffset;

        var scrollSize = gantt.config.scroll_size || scrollDefaultSize;

        var position = {
          y: oldPos.y + offsetY,
          x: oldPos.x + offsetX,
          bottom: oldPos.y + markerSize.height + offsetY + scrollSize,
          right: oldPos.x + markerSize.width + offsetX + scrollSize
        };

        if (position.bottom > viewportSize.bottom) {
          position.y = viewportSize.bottom - markerSize.height - offsetY;
        }

        if (position.right > viewportSize.right) {
          position.x = viewportSize.right - markerSize.width - offsetX;
        }
        return position;
      }

      dnd.attachEvent("onDragMove", gantt.bind(function (obj, e) {
        var dd = dnd.config;
        var pos = getPosition(e, dd.marker);
        advanceMarker(dd.marker, pos);
        var landing = !!domHelpers.locateClassName(e, link_landing_hover_area);

        var prevTarget = _link_target_task;
        var prevLanding = _link_landing;
        var prevToStart = _link_target_task_start;

        var targ = gantt.locate(e),
          to_start = true;

        // can drag and drop link to another gantt on the page, such links are not supported
        var sameGantt = domHelpers.isChildOf(e.target || e.srcElement, gantt.$root);
        if (!sameGantt) {
          landing = false;
          targ = null;
        }

        if (landing) {
          //refreshTask
          to_start = !domHelpers.locateClassName(e, end_marker);
          landing = !!targ;
        }

        _link_target_task = targ;
        _link_landing = landing;
        _link_target_task_start = to_start;

        if (landing) {
          var t = gantt.getTask(targ);

          var config = timeline.$getConfig();
          var node = domHelpers.locateClassName(e, link_landing_hover_area);
          var shift = 0;
          if (node) {
            shift = Math.floor(node.offsetWidth / 2);
          }

          this._dir_end = getLinePos(t, !!_link_target_task_start, shift, config);
        } else {
          this._dir_end = domHelpers.getRelativeEventPosition(e, timeline.$task_data);
        }

        var targetChanged = !(prevLanding == landing && prevTarget == targ && prevToStart == to_start);
        if (targetChanged) {
          if (prevTarget)
            gantt.refreshTask(prevTarget, false);
          if (targ)
            gantt.refreshTask(targ, false);
        }

        if (targetChanged) {
          updateMarkedHtml(dd.marker);
        }

        showDirectingLine(this._dir_start.x, this._dir_start.y, this._dir_end.x, this._dir_end.y);

        return true;
      }, this));


      dnd.attachEvent("onDragEnd", gantt.bind(function () {
        var drag = getDndState();

        if (drag.link_source_id && drag.link_target_id && drag.link_source_id != drag.link_target_id) {
          var type = gantt._get_link_type(drag.link_from_start, drag.link_to_start);

          var link = { source: drag.link_source_id, target: drag.link_target_id, type: type };
          if (link.type && gantt.isLinkAllowed(link)) {
            if (gantt.callEvent("onLinkCreated", [link])) {
              gantt.addLink(link);
            }
          }
        }

        resetDndState();

        if (gantt.config.touch) {
          gantt.refreshData();
        }
        else {
          if (drag.link_source_id)
            gantt.refreshTask(drag.link_source_id, false);
          if (drag.link_target_id)
            gantt.refreshTask(drag.link_target_id, false);
        }
        removeDirectionLine();
      }, this));

      function updateMarkedHtml(marker) {
        var link = getDndState();

        var css = ["gantt_link_tooltip"];
        if (link.link_source_id && link.link_target_id) {
          if (gantt.isLinkAllowed(link.link_source_id, link.link_target_id, link.link_from_start, link.link_to_start)) {
            css.push("gantt_allowed_link");
          } else {
            css.push("gantt_invalid_link");
          }
        }

        var className = gantt.templates.drag_link_class(link.link_source_id, link.link_from_start, link.link_target_id, link.link_to_start);
        if (className)
          css.push(className);

        var html = "<div class='" + className + "'>" +
          gantt.templates.drag_link(link.link_source_id, link.link_from_start, link.link_target_id, link.link_to_start) +
          "</div>";
        marker.innerHTML = html;
      }

      function advanceMarker(marker, pos) {
        marker.style.left = pos.x + "px";
        marker.style.top = pos.y + "px";
      }

      function resetDndState() {
        _link_source_task =
          _link_source_task_start =
          _link_target_task = null;
        _link_target_task_start = true;
      }
      function showDirectingLine(s_x, s_y, e_x, e_y) {
        var div = getDirectionLine();

        var link = getDndState();

        var css = ["gantt_link_direction"];
        if (gantt.templates.link_direction_class) {
          css.push(gantt.templates.link_direction_class(link.link_source_id, link.link_from_start, link.link_target_id, link.link_to_start));
        }

        var dist = Math.sqrt((Math.pow(e_x - s_x, 2)) + (Math.pow(e_y - s_y, 2)));
        dist = Math.max(0, dist - 3);
        if (!dist)
          return;

        div.className = css.join(" ");
        var tan = (e_y - s_y) / (e_x - s_x),
          angle = Math.atan(tan);

        if (coordinateCircleQuarter(s_x, e_x, s_y, e_y) == 2) {
          angle += Math.PI;
        } else if (coordinateCircleQuarter(s_x, e_x, s_y, e_y) == 3) {
          angle -= Math.PI;
        }



        var sin = Math.sin(angle),
          cos = Math.cos(angle),
          top = Math.round(s_y),
          left = Math.round(s_x);


        var style = [
          "-webkit-transform: rotate(" + angle + "rad)",
          "-moz-transform: rotate(" + angle + "rad)",
          "-ms-transform: rotate(" + angle + "rad)",
          "-o-transform: rotate(" + angle + "rad)",
          "transform: rotate(" + angle + "rad)",
          "width:" + Math.round(dist) + "px"
        ];

        if (window.navigator.userAgent.indexOf("MSIE 8.0") != -1) {
          //ms-filter breaks styles in ie9, so add it only for 8th
          style.push("-ms-filter: \"" + ieTransform(sin, cos) + "\"");

          var shiftLeft = Math.abs(Math.round(s_x - e_x)),
            shiftTop = Math.abs(Math.round(e_y - s_y));
          //fix rotation axis
          switch (coordinateCircleQuarter(s_x, e_x, s_y, e_y)) {
            case 1:
              top -= shiftTop;
              break;
            case 2:
              left -= shiftLeft;
              top -= shiftTop;
              break;
            case 3:
              left -= shiftLeft;
              break;
            default:
              break;
          }

        }

        style.push("top:" + top + "px");
        style.push("left:" + left + "px");

        div.style.cssText = style.join(";");
      }

      function ieTransform(sin, cos) {
        return "progid:DXImageTransform.Microsoft.Matrix(" +
          "M11 = " + cos + "," +
          "M12 = -" + sin + "," +
          "M21 = " + sin + "," +
          "M22 = " + cos + "," +
          "SizingMethod = 'auto expand'" +
          ")";
      }
      function coordinateCircleQuarter(sX, eX, sY, eY) {
        if (eX >= sX) {
          if (eY <= sY) {
            return 1;
          } else {
            return 4;
          }
        } else {
          if (eY <= sY) {
            return 2;
          } else {
            return 3;
          }
        }

      }
      function getDirectionLine() {
        if (!dnd._direction || !dnd._direction.parentNode) {
          dnd._direction = document.createElement("div");
          timeline.$task_links.appendChild(dnd._direction);
        }
        return dnd._direction;
      }
      function removeDirectionLine() {
        if (dnd._direction) {
          if (dnd._direction.parentNode)	//the event line can be detached because of data refresh
            dnd._direction.parentNode.removeChild(dnd._direction);

          dnd._direction = null;
        }
      }
      gantt.attachEvent("onGanttRender", gantt.bind(function () {
        if (dnd._direction) {
          showDirectingLine(this._dir_start.x, this._dir_start.y, this._dir_end.x, this._dir_end.y);
        }
      }, this));
    };

    return {
      createLinkDND: function () {
        return {
          init: initLinksDND
        };
      }
    };

    /***/
  }

  mainTimelineInitializer(outerThis?: TimelineService) {

    var utils = this.utilsService.utils(),
      taskDnD = this.tasks_dnd(),
      linkDnD = this.linksDnd(),
      domHelpers = this.utilsService.domHelpers();

    var initializer = (function () {
      return function (gantt) {
        var services = gantt.$services;
        return {
          onCreated: function (timeline) {
            var config = timeline.$config;
            config.bind = utils.defined(config.bind) ? config.bind : "task";
            config.bindLinks = utils.defined(config.bindLinks) ? config.bindLinks : "link";

            timeline._linksDnD = linkDnD.createLinkDND();
            timeline._tasksDnD = taskDnD.createTaskDND();
            timeline._tasksDnD.extend(timeline);

            this._mouseDelegates = outerThis.mouseEventContainer(gantt);
          },
          onInitialized: function (timeline) {
            this._attachDomEvents(gantt);

            this._attachStateProvider(gantt, timeline);

            timeline._tasksDnD.init(timeline, gantt);
            timeline._linksDnD.init(timeline, gantt);

            if (timeline.$config.id == "timeline") {
              this.extendDom(timeline);
            }

          },
          onDestroyed: function (timeline) {
            this._clearDomEvents(gantt);
            this._clearStateProvider(gantt);
            if (timeline._tasksDnD) {
              timeline._tasksDnD.destructor();
            }
          },
          extendDom: function (timeline) {
            gantt.$task = timeline.$task;
            gantt.$task_scale = timeline.$task_scale;
            gantt.$task_data = timeline.$task_data;
            gantt.$task_bg = timeline.$task_bg;
            gantt.$task_links = timeline.$task_links;
            gantt.$task_bars = timeline.$task_bars;
          },

          _clearDomEvents: function () {
            this._mouseDelegates.destructor();
            this._mouseDelegates = null;
          },

          _attachDomEvents: function (gantt) {
            function _delete_link_handler(id, e) {
              if (id && this.callEvent("onLinkDblClick", [id, e])) {

                var link = this.getLink(id);
                if (this.isReadonly(link)) return;

                var title = "";
                var question = this.locale.labels.link + " " + this.templates.link_description(this.getLink(id)) + " " + this.locale.labels.confirm_link_deleting;

                window.setTimeout(function () {
                  gantt._dhtmlx_confirm(question, title, function () {
                    gantt.deleteLink(id);
                  });
                }, (this.config.touch ? 300 : 1));
              }
            }

            this._mouseDelegates.delegate("click", "gantt_task_link", gantt.bind(function (e, trg) {
              var id = this.locate(e, this.config.link_attribute);
              if (id) {
                this.callEvent("onLinkClick", [id, e]);
              }
            }, gantt), this.$task);

            this._mouseDelegates.delegate("click", "gantt_scale_cell", gantt.bind(function (e, trg) {
              var pos = domHelpers.getRelativeEventPosition(e, gantt.$task_data);
              var date = gantt.dateFromPos(pos.x);
              var coll = Math.floor(gantt.columnIndexByDate(date));

              var coll_date = gantt.getScale().trace_x[coll];

              gantt.callEvent("onScaleClick", [e, coll_date]);
            }, gantt), this.$task);

            this._mouseDelegates.delegate("doubleclick", "gantt_task_link", gantt.bind(function (e, id, trg) {
              var id = this.locate(e, gantt.config.link_attribute);
              _delete_link_handler.call(this, id, e);
            }, gantt), this.$task);

            this._mouseDelegates.delegate("doubleclick", "gantt_link_point", gantt.bind(function (e, id, trg) {
              var id = this.locate(e),
                task = this.getTask(id);

              var link = null;
              if (trg.parentNode && domHelpers.getClassName(trg.parentNode)) {
                if (domHelpers.getClassName(trg.parentNode).indexOf("_left") > -1) {
                  link = task.$target[0];
                } else {
                  link = task.$source[0];
                }
              }
              if (link)
                _delete_link_handler.call(this, link, e);
              return false;
            }, gantt), this.$task);
          },

          _attachStateProvider: function (gantt, timeline) {
            var self = timeline;
            var state = services.getService("state");
            state.registerProvider("tasksTimeline", function () {
              return {
                scale_unit: self._tasks ? self._tasks.unit : undefined,
                scale_step: self._tasks ? self._tasks.step : undefined
              };
            });
          },

          _clearStateProvider: function () {
            var state = services.getService("state");
            state.unregisterProvider("tasksTimeline");
          }
        };
      };

    })();

    return initializer;

    /***/
  }

  scales() {

    var utils = this.utilsService.utils();

    function ScaleHelper(gantt) {
      var dateHelper = gantt.date;
      var services = gantt.$services;

      return {
        getSum: function (sizes, from, to) {
          if (to === undefined)
            to = sizes.length - 1;
          if (from === undefined)
            from = 0;

          var summ = 0;
          for (var i = from; i <= to; i++)
            summ += sizes[i];

          return summ;
        },
        setSumWidth: function (sum_width, scale, from, to) {
          var parts = scale.width;

          if (to === undefined)
            to = parts.length - 1;
          if (from === undefined)
            from = 0;
          var length = to - from + 1;

          if (from > parts.length - 1 || length <= 0 || to > parts.length - 1)
            return;

          var oldWidth = this.getSum(parts, from, to);

          var diff = sum_width - oldWidth;

          this.adjustSize(diff, parts, from, to);
          this.adjustSize(-diff, parts, to + 1);

          scale.full_width = this.getSum(parts);
        },
        splitSize: function (width, count) {
          var arr = [];
          for (var i = 0; i < count; i++) arr[i] = 0;

          this.adjustSize(width, arr);
          return arr;

        },
        adjustSize: function (width, parts, from, to) {
          if (!from)
            from = 0;
          if (to === undefined)
            to = parts.length - 1;

          var length = to - from + 1;

          var full = this.getSum(parts, from, to);

          for (var i = from; i <= to; i++) {
            var share = Math.floor(width * (full ? (parts[i] / full) : (1 / length)));

            full -= parts[i];
            width -= share;
            length--;

            parts[i] += share;
          }
          parts[parts.length - 1] += width;
        },
        sortScales: function (scales) {
          function cellSize(unit, step) {
            var d = new Date(1970, 0, 1);
            return dateHelper.add(d, step, unit) - new Date(d).getDate();
          }

          scales.sort(function (a, b) {
            if (cellSize(a.unit, a.step) < cellSize(b.unit, b.step)) {
              return 1;
            } else if (cellSize(a.unit, a.step) > cellSize(b.unit, b.step)) {
              return -1;
            } else {
              return 0;
            }
          });

          for (var i = 0; i < scales.length; i++) {
            scales[i].index = i;
          }
        },
        _isLegacyMode: function (config) {
          var scaleConfig = config || services.config();
          return scaleConfig.scale_unit || scaleConfig.date_scale || scaleConfig.subscales;
        },
        _prepareScaleObject: function (scale) {
          var format = scale.format;
          if (!format) {
            format = scale.template || scale.date || "%d %M";
          }

          if (typeof format === "string") {
            format = gantt.date.date_to_str(format);
          }
          return {
            unit: scale.unit || "day",
            step: scale.step || 1,
            format: format,
            css: scale.css
          };
        },
        primaryScale: function (config?) {
          var templates = services.getService("templateLoader");
          var legacyMode = this._isLegacyMode(config);

          var scaleConfig = config || services.config();

          var result;
          if (legacyMode) {
            templates.initTemplate("date_scale", undefined, undefined, scaleConfig, services.templates());
            result = {
              unit: services.config().scale_unit,
              step: services.config().step,
              template: services.templates().date_scale,
              date: services.config().date_scale,
              css: services.templates().scale_cell_class
            };
          } else {
            var primaryScale = scaleConfig.scales[0];
            result = {
              unit: primaryScale.unit,
              step: primaryScale.step,
              template: primaryScale.template,
              format: primaryScale.format,
              date: primaryScale.date,
              css: primaryScale.css || services.templates().scale_cell_class
            };
          }

          return this._prepareScaleObject(result);
        },
        getSubScales: function (config?) {
          var legacyMode = this._isLegacyMode(config);
          var scaleConfig = config || services.config();
          var scales;
          if (legacyMode) {
            scales = scaleConfig.subscales || [];
          } else {
            scales = scaleConfig.scales.slice(1);
          }

          return scales.map(function (scale) {
            return this._prepareScaleObject(scale);
          }.bind(this));
        },

        prepareConfigs: function (scales, min_coll_width, container_width, scale_height, minDate, maxDate, rtl) {
          var heights = this.splitSize(scale_height, scales.length);
          var full_width = container_width;

          var configs = [];
          for (var i = scales.length - 1; i >= 0; i--) {
            var main_scale = (i == scales.length - 1);
            var cfg = this.initScaleConfig(scales[i], minDate, maxDate);
            if (main_scale) {
              this.processIgnores(cfg);
            }

            this.initColSizes(cfg, min_coll_width, full_width, heights[i]);
            this.limitVisibleRange(cfg);

            if (main_scale) {
              full_width = cfg.full_width;
            }

            configs.unshift(cfg);
          }


          for (var i = 0; i < configs.length - 1; i++) {
            this.alineScaleColumns(configs[configs.length - 1], configs[i]);
          }
          for (var i = 0; i < configs.length; i++) {

            if (rtl) {
              this.reverseScale(configs[i]);
            }
            this.setPosSettings(configs[i]);
          }
          return configs;

        },

        reverseScale: function (scale) {
          scale.width = scale.width.reverse();
          scale.trace_x = scale.trace_x.reverse();

          var indexes = scale.trace_indexes;
          scale.trace_indexes = {};
          scale.trace_index_transition = {};
          scale.rtl = true;
          for (var i = 0; i < scale.trace_x.length; i++) {
            scale.trace_indexes[scale.trace_x[i].valueOf()] = i;
            scale.trace_index_transition[indexes[scale.trace_x[i].valueOf()]] = i;
          }
          return scale;
        },

        setPosSettings: function (config) {
          for (var i = 0, len = config.trace_x.length; i < len; i++) {
            config.left.push((config.width[i - 1] || 0) + (config.left[i - 1] || 0));
          }
        },

        _ignore_time_config: function (date, scale) {

          if (services.config().skip_off_time) {
            var skip = true;
            var probe = date;

            // check dates in case custom scale unit, e.g. {unit: "month", step: 3}
            for (var i = 0; i < scale.step; i++) {
              if (i) {
                probe = dateHelper.add(date, i, scale.unit);
              }

              skip = skip && !this.isWorkTime(probe, scale.unit);
            }

            return skip;
          }
          return false;
        },
        //defined in an extension
        processIgnores: function (config) {
          config.ignore_x = {};
          config.display_count = config.count;
        },
        initColSizes: function (config, min_col_width, full_width, line_height) {
          var cont_width = full_width;

          config.height = line_height;

          var column_count = config.display_count === undefined ? config.count : config.display_count;

          if (!column_count)
            column_count = 1;

          config.col_width = Math.floor(cont_width / column_count);

          if (min_col_width) {
            if (config.col_width < min_col_width) {
              config.col_width = min_col_width;
              cont_width = config.col_width * column_count;
            }
          }
          config.width = [];
          var ignores = config.ignore_x || {};
          for (var i = 0; i < config.trace_x.length; i++) {
            if (ignores[config.trace_x[i].valueOf()] || (config.display_count == config.count)) {
              config.width[i] = 0;
            } else {
              // width of month columns should be proportional month duration
              var width = 1;
              if (config.unit == "month") {
                var days = Math.round((dateHelper.add(config.trace_x[i], config.step, config.unit) - config.trace_x[i]) / (1000 * 60 * 60 * 24));
                width = days;
              }
              config.width[i] = width;
            }
          }

          this.adjustSize(cont_width - this.getSum(config.width)/* 1 width per column from the code above */, config.width);
          config.full_width = this.getSum(config.width);
        },
        initScaleConfig: function (config, min_date, max_date) {
          var cfg = utils.mixin({
            count: 0,
            col_width: 0,
            full_width: 0,
            height: 0,
            width: [],
            left: [],
            trace_x: [],
            trace_indexes: {},
            min_date: new Date(min_date),
            max_date: new Date(max_date)
          }, config);

          this.eachColumn(config.unit, config.step, min_date, max_date, function (date) {
            cfg.count++;
            cfg.trace_x.push(new Date(date));
            cfg.trace_indexes[date.valueOf()] = cfg.trace_x.length - 1;
          });

          cfg.trace_x_ascending = cfg.trace_x.slice();
          return cfg;
        },
        iterateScales: function (lower_scale, upper_scale, from, to, callback) {
          var upper_dates = upper_scale.trace_x;
          var lower_dates = lower_scale.trace_x;

          var prev = from || 0;
          var end = to || (lower_dates.length - 1);
          var prevUpper = 0;


          for (var up = 1; up < upper_dates.length; up++) {
            var target_index = (lower_scale.trace_indexes[+upper_dates[up]]);
            if (target_index !== undefined && target_index <= end) {
              if (callback) {
                callback.apply(this, [prevUpper, up, prev, target_index]);
              }
              prev = target_index;
              prevUpper = up;
              continue;
            }
          }
        },
        alineScaleColumns: function (lower_scale, upper_scale, from, to) {
          this.iterateScales(lower_scale, upper_scale, from, to, function (upper_start, upper_end, lower_start, lower_end) {
            var targetWidth = this.getSum(lower_scale.width, lower_start, lower_end - 1);
            var actualWidth = this.getSum(upper_scale.width, upper_start, upper_end - 1);
            if (actualWidth != targetWidth) {
              this.setSumWidth(targetWidth, upper_scale, upper_start, upper_end - 1);
            }

          });
        },

        eachColumn: function (unit, step, min_date, max_date, callback) {
          var start = new Date(min_date),
            end = new Date(max_date);
          if (dateHelper[unit + "_start"]) {
            start = dateHelper[unit + "_start"](start);
          }

          var curr = new Date(start);
          if (+curr >= +end) {
            end = dateHelper.add(curr, step, unit);
          }
          while (+curr < +end) {
            callback.call(this, new Date(curr));
            var tzOffset = curr.getTimezoneOffset();
            curr = dateHelper.add(curr, step, unit);
            curr = gantt._correct_dst_change(curr, tzOffset, step, unit);
            if (dateHelper[unit + '_start'])
              curr = dateHelper[unit + "_start"](curr);
          }
        },
        limitVisibleRange: function (cfg) {
          var dates = cfg.trace_x;

          var left = 0, right = cfg.width.length - 1;
          var diff = 0;
          if (+dates[0] < +cfg.min_date && left != right) {
            var width = Math.floor(cfg.width[0] * ((dates[1] - cfg.min_date) / (dates[1] - dates[0])));
            diff += cfg.width[0] - width;
            cfg.width[0] = width;

            dates[0] = new Date(cfg.min_date);
          }

          var last = dates.length - 1;
          var lastDate = dates[last];
          var outDate = dateHelper.add(lastDate, cfg.step, cfg.unit);
          if (+outDate > +cfg.max_date && last > 0) {
            var width = cfg.width[last] - Math.floor(cfg.width[last] * ((outDate - cfg.max_date) / (outDate - lastDate)));
            diff += cfg.width[last] - width;
            cfg.width[last] = width;
          }

          if (diff) {
            var full = this.getSum(cfg.width);
            var shared = 0;
            for (var i = 0; i < cfg.width.length; i++) {
              var share = Math.floor(diff * (cfg.width[i] / full));
              cfg.width[i] += share;
              shared += share;
            }
            this.adjustSize(diff - shared, cfg.width);
          }

        }
      };
    }

    return ScaleHelper;


    /***/
  }

  tasksCanvasRender() {

    var createStaticBgHelper = function () {
      return {
        render: function () { },
        destroy: function () { }
      };
    };

    return {
      create: function () {
        return createStaticBgHelper();
      }
    };



    /***/
  }

  tasks_dnd() {

    var domHelpers = this.utilsService.domHelpers(),
      utils = this.utilsService.utils();
    var timeout = this.utilsService.timeout();

    function createTaskDND(timeline, gantt) {
      var services = gantt.$services;
      return {
        drag: null,
        dragMultiple: {},
        _events: {
          before_start: {},
          before_finish: {},
          after_finish: {}
        },
        _handlers: {},
        init: function () {
          this._domEvents = gantt._createDomEventScope();
          this.clear_drag_state();
          var drag = gantt.config.drag_mode;
          this.set_actions();

          var stateService = services.getService("state");
          stateService.registerProvider("tasksDnd", utils.bind(function () {
            return {
              drag_id: this.drag ? this.drag.id : undefined,
              drag_mode: this.drag ? this.drag.mode : undefined,
              drag_from_start: this.drag ? this.drag.left : undefined
            };
          }, this));

          var evs = {
            "before_start": "onBeforeTaskDrag",
            "before_finish": "onBeforeTaskChanged",
            "after_finish": "onAfterTaskDrag"
          };
          //for now, all drag operations will trigger the same events
          for (var stage in this._events) {
            for (var mode in drag) {
              this._events[stage][mode] = evs[stage];
            }
          }

          this._handlers[drag.move] = this._move;
          this._handlers[drag.resize] = this._resize;
          this._handlers[drag.progress] = this._resize_progress;
        },
        set_actions: function () {
          var data = timeline.$task_data;
          this._domEvents.attach(data, "mousemove", gantt.bind(function (e) {
            this.on_mouse_move(e || event);
          }, this));
          this._domEvents.attach(data, "mousedown", gantt.bind(function (e) {
            this.on_mouse_down(e || event);
          }, this));
          this._domEvents.attach(gantt.$root, "mouseup", gantt.bind(function (e) {
            this.on_mouse_up(e || event);
          }, this));
        },

        clear_drag_state: function () {
          this.drag = {
            id: null,
            mode: null,
            pos: null,
            start_x: null,
            start_y: null,
            obj: null,
            left: null
          };
          this.dragMultiple = {};
        },
        _resize: function (ev, shift, drag) {
          var cfg = timeline.$getConfig();
          var coords_x = this._drag_task_coords(ev, drag);
          if (drag.left) {
            ev.start_date = gantt.dateFromPos(coords_x.start + shift);
            if (!ev.start_date) {
              ev.start_date = new Date(gantt.getState().min_date);
            }
          } else {
            ev.end_date = gantt.dateFromPos(coords_x.end + shift);
            if (!ev.end_date) {
              ev.end_date = new Date(gantt.getState().max_date);
            }
          }

          if (ev.end_date - ev.start_date < cfg.min_duration) {
            if (drag.left)
              ev.start_date = gantt.calculateEndDate({ start_date: ev.end_date, duration: -1, task: ev });
            else
              ev.end_date = gantt.calculateEndDate({ start_date: ev.start_date, duration: 1, task: ev });
          }
          gantt._init_task_timing(ev);
        },
        _resize_progress: function (ev, shift, drag) {
          var coords_x = this._drag_task_coords(ev, drag);

          var config = timeline.$getConfig();
          var diffValue = !config.rtl ? (drag.pos.x - coords_x.start) : (coords_x.start - drag.pos.x);

          var diff = Math.max(0, diffValue);
          ev.progress = Math.min(1, diff / Math.abs(coords_x.end - coords_x.start));
        },

        _find_max_shift: function (dragItems, shift) {
          var correctShift;
          for (var i in dragItems) {
            var drag = dragItems[i];
            var ev = gantt.getTask(drag.id);

            var coords_x = this._drag_task_coords(ev, drag);
            var minX = gantt.posFromDate(new Date(gantt.getState().min_date)),
              maxX = gantt.posFromDate(new Date(gantt.getState().max_date));

            if (coords_x.end + shift > maxX) {
              var maxShift = maxX - coords_x.end;
              if (maxShift < correctShift || correctShift === undefined) {
                correctShift = maxShift;
              }
            } else if (coords_x.start + shift < minX) {
              var minShift = minX - coords_x.start;
              if (minShift < correctShift || correctShift === undefined) {
                correctShift = minShift;
              }
            }
          }
          return correctShift;
        },
        _move: function (ev, shift, drag) {
          var coords_x = this._drag_task_coords(ev, drag);
          var new_start = gantt.dateFromPos(coords_x.start + shift),
            new_end = gantt.dateFromPos(coords_x.end + shift);
          if (!new_start) {
            ev.start_date = new Date(gantt.getState().min_date);
            ev.end_date = gantt.dateFromPos(gantt.posFromDate(ev.start_date) + (coords_x.end - coords_x.start));
          } else if (!new_end) {
            ev.end_date = new Date(gantt.getState().max_date);
            ev.start_date = gantt.dateFromPos(gantt.posFromDate(ev.end_date) - (coords_x.end - coords_x.start));
          } else {
            ev.start_date = new_start;
            ev.end_date = new_end;
          }
        },
        _drag_task_coords: function (t, drag) {
          var start = drag.obj_s_x = drag.obj_s_x || gantt.posFromDate(t.start_date);
          var end = drag.obj_e_x = drag.obj_e_x || gantt.posFromDate(t.end_date);
          return {
            start: start,
            end: end
          };
        },
        _mouse_position_change: function (oldPos, newPos) {
          var dx = oldPos.x - newPos.x,
            dy = oldPos.y - newPos.y;
          return Math.sqrt(dx * dx + dy * dy);
        },
        _is_number: function (n) {
          return !isNaN(parseFloat(n)) && isFinite(n);
        },

        on_mouse_move: function (e) {
          if (this.drag.start_drag) {
            var pos = domHelpers.getRelativeEventPosition(e, gantt.$task_data);

            var sX = this.drag.start_drag.start_x,
              sY = this.drag.start_drag.start_y;

            if ((Date.now() - this.drag.timestamp > 50) ||
              (this._is_number(sX) && this._is_number(sY) && this._mouse_position_change({
                x: sX,
                y: sY
              }, pos) > 20)) {
              this._start_dnd(e);
            }
          }

          var drag = this.drag;

          if (drag.mode) {
            if (!timeout(this, 40))//limit update frequency
              return;

            this._update_on_move(e);

          }
        },

        _update_item_on_move: function (shift, id, mode, drag, e) {
          var ev = gantt.getTask(id);
          var original = gantt.mixin({}, ev);
          var copy = gantt.mixin({}, ev);
          this._handlers[mode].apply(this, [copy, shift, drag]);
          gantt.mixin(ev, copy, true);
          //gantt._update_parents(drag.id, true);
          gantt.callEvent("onTaskDrag", [ev.id, mode, copy, original, e]);
          gantt.mixin(ev, copy, true);
          gantt.refreshTask(id);
        },

        _update_on_move: function (e) {
          var drag = this.drag;
          var config = timeline.$getConfig();
          if (drag.mode) {
            var pos = domHelpers.getRelativeEventPosition(e, timeline.$task_data);
            if (drag.pos && drag.pos.x == pos.x)
              return;

            drag.pos = pos;

            var curr_date = gantt.dateFromPos(pos.x);
            if (!curr_date || isNaN(curr_date.getTime()))
              return;


            var shift = pos.x - drag.start_x;
            var ev = gantt.getTask(drag.id);

            if (this._handlers[drag.mode]) {

              if (gantt.isSummaryTask(ev) && gantt.config.drag_project && drag.mode == config.drag_mode.move) {

                var initialDrag = {};
                initialDrag[drag.id] = utils.copy(drag);
                var maxShift = this._find_max_shift(utils.mixin(initialDrag, this.dragMultiple), shift);
                if (maxShift !== undefined) {
                  shift = maxShift;
                }

                this._update_item_on_move(shift, drag.id, drag.mode, drag, e);
                for (var i in this.dragMultiple) {
                  var childDrag = this.dragMultiple[i];
                  this._update_item_on_move(shift, childDrag.id, childDrag.mode, childDrag, e);
                }
              } else {
                this._update_item_on_move(shift, drag.id, drag.mode, drag, e);
              }
              gantt._update_parents(drag.id);
            }

          }
        },

        on_mouse_down: function (e, src) {
          // on Mac we do not get onmouseup event when clicking right mouse button leaving us in dnd state
          // let's ignore right mouse button then
          if (e.button == 2 && e.button !== undefined)
            return;

          var config = timeline.$getConfig();
          var id = gantt.locate(e);
          var task = null;
          if (gantt.isTaskExists(id)) {
            task = gantt.getTask(id);
          }

          if (gantt.isReadonly(task) || this.drag.mode) return;

          this.clear_drag_state();

          src = src || (e.target || e.srcElement);

          var className = domHelpers.getClassName(src);
          var drag = this._get_drag_mode(className, src);

          if (!className || !drag) {
            if (src.parentNode)
              return this.on_mouse_down(e, src.parentNode);
            else
              return;
          }

          if (!drag) {
            if (gantt.checkEvent("onMouseDown") && gantt.callEvent("onMouseDown", [className.split(" ")[0]])) {
              if (src.parentNode)
                return this.on_mouse_down(e, src.parentNode);

            }
          } else {
            if (drag.mode && drag.mode != config.drag_mode.ignore && config["drag_" + drag.mode]) {
              id = gantt.locate(src);
              task = gantt.copy(gantt.getTask(id) || {});

              if (gantt.isReadonly(task)) {
                this.clear_drag_state();
                return false;
              }

              if ((gantt.isSummaryTask(task) && !config.drag_project) && drag.mode != config.drag_mode.progress) {//only progress drag is allowed for tasks with flexible duration
                this.clear_drag_state();
                return;
              }

              drag.id = id;
              var pos = domHelpers.getRelativeEventPosition(e, gantt.$task_data);

              drag.start_x = pos.x;
              drag.start_y = pos.y;
              drag.obj = task;
              this.drag.start_drag = drag;
              this.drag.timestamp = Date.now();

            } else
              this.clear_drag_state();
          }
        },
        _fix_dnd_scale_time: function (task, drag) {
          var config = timeline.$getConfig();
          var unit = gantt.getScale().unit,
            step = gantt.getScale().step;
          if (!config.round_dnd_dates) {
            unit = 'minute';
            step = config.time_step;
          }

          function fixStart(task) {
            if (!gantt.config.correct_work_time)
              return;
            var config = timeline.$getConfig();
            if (!gantt.isWorkTime(task.start_date, undefined, task))
              task.start_date = gantt.calculateEndDate({
                start_date: task.start_date,
                duration: -1,
                unit: config.duration_unit,
                task: task
              });
          }

          function fixEnd(task) {
            if (!gantt.config.correct_work_time)
              return;
            var config = timeline.$getConfig();
            if (!gantt.isWorkTime(new Date(task.end_date - 1), undefined, task))
              task.end_date = gantt.calculateEndDate({
                start_date: task.end_date,
                duration: 1,
                unit: config.duration_unit,
                task: task
              });
          }

          if (drag.mode == config.drag_mode.resize) {
            if (drag.left) {
              task.start_date = gantt.roundDate({ date: task.start_date, unit: unit, step: step });
              fixStart(task);
            } else {
              task.end_date = gantt.roundDate({ date: task.end_date, unit: unit, step: step });
              fixEnd(task);
            }
          } else if (drag.mode == config.drag_mode.move) {
            task.start_date = gantt.roundDate({ date: task.start_date, unit: unit, step: step });
            fixStart(task);
            task.end_date = gantt.calculateEndDate(task);
          }
        },
        _fix_working_times: function (task, drag) {
          var config = timeline.$getConfig();
          var drag = drag || { mode: config.drag_mode.move };

          if (drag.mode == config.drag_mode.resize) {
            if (drag.left) {
              task.start_date = gantt.getClosestWorkTime({ date: task.start_date, dir: 'future', task: task });
            } else {
              task.end_date = gantt.getClosestWorkTime({ date: task.end_date, dir: 'past', task: task });
            }
          } else if (drag.mode == config.drag_mode.move) {
            gantt.correctTaskWorkTime(task);
          }
        },

        _finalize_mouse_up: function (taskId, config, drag, e) {
          var ev = gantt.getTask(taskId);

          if (config.work_time && config.correct_work_time) {
            this._fix_working_times(ev, drag);
          }

          this._fix_dnd_scale_time(ev, drag);

          if (!this._fireEvent("before_finish", drag.mode, [taskId, drag.mode, gantt.copy(drag.obj), e])) {
            //drag.obj._dhx_changed = false;
            this.clear_drag_state();
            if (taskId == drag.id) {
              drag.obj._dhx_changed = false;
              gantt.mixin(ev, drag.obj, true);
            }


            gantt.refreshTask(ev.id);
          } else {
            var drag_id = taskId;

            gantt._init_task_timing(ev);

            this.clear_drag_state();
            gantt.updateTask(ev.id);
            this._fireEvent("after_finish", drag.mode, [drag_id, drag.mode, e]);
          }

        },

        on_mouse_up: function (e) {

          var drag = this.drag;
          if (drag.mode && drag.id) {
            var config = timeline.$getConfig();
            //drop
            var ev = gantt.getTask(drag.id);
            var dragMultiple = this.dragMultiple;

            if (gantt.isSummaryTask(ev) && config.drag_project && drag.mode == config.drag_mode.move) {
              for (var i in dragMultiple) {
                this._finalize_mouse_up(dragMultiple[i].id, config, dragMultiple[i], e);
              }
            }
            this._finalize_mouse_up(drag.id, config, drag, e);
          }
          this.clear_drag_state();
        },
        _get_drag_mode: function (className, el) {
          var config = timeline.$getConfig();
          var modes = config.drag_mode;
          var classes = (className || "").split(" ");
          var classname = classes[0];
          var drag = { mode: null, left: null };
          switch (classname) {
            case "gantt_task_line":
            case "gantt_task_content":
              drag.mode = modes.move;
              break;
            case "gantt_task_drag":
              drag.mode = modes.resize;

              var dragProperty = el.getAttribute("data-bind-property");

              if (dragProperty == "start_date") {
                drag.left = true;
              } else {
                drag.left = false;
              }
              break;
            case "gantt_task_progress_drag":
              drag.mode = modes.progress;
              break;
            case "gantt_link_control":
            case "gantt_link_point":
              drag.mode = modes.ignore;
              break;
            default:
              drag = null;
              break;
          }
          return drag;

        },

        _start_dnd: function (e) {
          var drag = this.drag = this.drag.start_drag;
          delete drag.start_drag;

          var cfg = timeline.$getConfig();
          var id = drag.id;
          if (!cfg["drag_" + drag.mode] || !gantt.callEvent("onBeforeDrag", [id, drag.mode, e]) || !this._fireEvent("before_start", drag.mode, [id, drag.mode, e])) {
            this.clear_drag_state();
          } else {
            delete drag.start_drag;

            var task = gantt.getTask(id);
            if (gantt.isSummaryTask(task) && gantt.config.drag_project && drag.mode == cfg.drag_mode.move) {
              gantt.eachTask(function (child) {
                this.dragMultiple[child.id] = gantt.mixin({
                  id: child.id,
                  obj: gantt.copy(child)
                }, this.drag);
              }, task.id, this);
            }

            gantt.callEvent("onTaskDragStart", []);
          }

        },
        _fireEvent: function (stage, mode, params) {
          gantt.assert(this._events[stage], "Invalid stage:{" + stage + "}");

          var trigger = this._events[stage][mode];

          gantt.assert(trigger, "Unknown after drop mode:{" + mode + "}");
          gantt.assert(params, "Invalid event arguments");


          if (!gantt.checkEvent(trigger))
            return true;

          return gantt.callEvent(trigger, params);
        },

        round_task_dates: function (task) {
          var drag_state = this.drag;
          var config = timeline.$getConfig();
          if (!drag_state) {
            drag_state = { mode: config.drag_mode.move };
          }
          this._fix_dnd_scale_time(task, drag_state);
        },
        destructor: function () {
          this._domEvents.detachAll();
        }
      };
    }

    function initTaskDND() {
      var _tasks_dnd;
      return {
        extend: function (timeline) {
          timeline.roundTaskDates = function (task) {
            _tasks_dnd.round_task_dates(task);
          };

        },
        init: function (timeline, gantt) {
          _tasks_dnd = createTaskDND(timeline, gantt);
          // TODO: entry point for touch handlers, move touch to timeline
          timeline._tasks_dnd = _tasks_dnd;
          return _tasks_dnd.init(gantt);
        },
        destructor: function () {
          if (_tasks_dnd) {
            _tasks_dnd.destructor();
            _tasks_dnd = null;
          }
        }
      };
    }

    return {
      createTaskDND: initTaskDND
    };


    /***/
  }

  timeline() {

    var ScaleHelper = this.scales();
    var eventable = this.utilsService.eventable();
    var utils = this.utilsService.utils();
    var topPositionMixin = this.rowPositionMixin();
    var canvasRender = this.tasksCanvasRender();

    var Timeline = function (parent, config, factory, gantt) {
      this.$config = utils.mixin({}, config || {});
      this.$scaleHelper = ScaleHelper(gantt);
      this.$gantt = gantt;
      this._posFromDateCache = {};
      utils.mixin(this, topPositionMixin());
      eventable(this);
    };

    Timeline.prototype = {
      init: function (container) {
        container.innerHTML += "<div class='gantt_task' style='width:inherit;height:inherit;'></div>";
        this.$task = container.childNodes[0];

        this.$task.innerHTML = "<div class='gantt_task_scale'></div><div class='gantt_data_area'></div>";
        this.$task_scale = this.$task.childNodes[0];

        this.$task_data = this.$task.childNodes[1];
        this.$task_data.innerHTML = "<div class='gantt_task_bg'></div><div class='gantt_links_area'></div><div class='gantt_bars_area'></div>";
        this.$task_bg = this.$task_data.childNodes[0];
        this.$task_links = this.$task_data.childNodes[1];
        this.$task_bars = this.$task_data.childNodes[2];

        this._tasks = {
          col_width: 0,
          width: [], // width of each column
          full_width: 0, // width of all columns
          trace_x: [],
          rendered: {}
        };

        var config = this.$getConfig();
        var attr = config[this.$config.bind + "_attribute"];
        var linksAttr = config[this.$config.bindLinks + "_attribute"];
        if (!attr && this.$config.bind) {
          attr = this.$config.bind + "_id";
        }
        if (!linksAttr && this.$config.bindLinks) {
          linksAttr = this.$config.bindLinks + "_id";
        }
        this.$config.item_attribute = attr || null;
        this.$config.link_attribute = linksAttr || null;

        var layers = this._createLayerConfig();
        if (!this.$config.layers) {
          this.$config.layers = layers.tasks;
        }
        if (!this.$config.linkLayers) {
          this.$config.linkLayers = layers.links;
        }

        this._attachLayers(this.$gantt);

        this.callEvent("onReady", []);
        //this.refresh();
      },

      setSize: function (width, height) {
        var config = this.$getConfig();

        if (width * 1 === width) {
          this.$config.width = width;
        }
        if (height * 1 === height) {

          this.$config.height = height;
          var dataHeight = Math.max(this.$config.height - config.scale_height);
          this.$task_data.style.height = dataHeight + 'px';
        }

        this.refresh();
        this.$task_bg.style.backgroundImage = "";

        if (config.smart_rendering && this.$config.rowStore) {
          var store = this.$config.rowStore;
          this.$task_bg.style.height = config.row_height * store.countVisible() + "px";
        } else {
          this.$task_bg.style.height = "";
        }

        var scale = this._tasks;
        //timeline area layers
        var data_els = this.$task_data.childNodes;
        for (var i = 0, len = data_els.length; i < len; i++) {
          var el = data_els[i];
          if (el.hasAttribute("data-layer") && el.style)
            el.style.width = scale.full_width + "px";
        }
      },

      isVisible: function () {
        if (this.$parent && this.$parent.$config) {
          return !this.$parent.$config.hidden;
        } else {
          return this.$task.offsetWidth;
        }
      },

      getSize: function () {
        var config = this.$getConfig();
        var store = this.$config.rowStore;

        var contentHeight = store ? config.row_height * store.countVisible() : 0,
          contentWidth = this.isVisible() ? this._tasks.full_width : 0;

        return {
          x: this.isVisible() ? this.$config.width : 0,
          y: this.isVisible() ? this.$config.height : 0,
          contentX: this.isVisible() ? contentWidth : 0,
          contentY: this.isVisible() ? (config.scale_height + contentHeight) : 0,
          scrollHeight: this.isVisible() ? contentHeight : 0,
          scrollWidth: this.isVisible() ? contentWidth : 0
        };
      },

      scrollTo: function (left, top) {
        if (!this.isVisible())
          return;

        var scrolled = false;

        this.$config.scrollTop = this.$config.scrollTop || 0;
        this.$config.scrollLeft = this.$config.scrollLeft || 0;
        if (top * 1 === top) {
          this.$config.scrollTop = top;
          this.$task_data.scrollTop = this.$config.scrollTop;
          scrolled = true;
        }
        if (left * 1 === left) {
          this.$task.scrollLeft = left;
          this.$config.scrollLeft = this.$task.scrollLeft;
          this._refreshScales();
          scrolled = true;
        }

        if (scrolled) {
          this.callEvent("onScroll", [this.$config.scrollLeft, this.$config.scrollTop]);
        }
      },

      _refreshScales: function _refreshScales() {
        if (!this.isVisible())
          return;

        var config = this.$getConfig();
        if (!config.smart_scales) return;

        var viewPort = this.getViewPort();

        var scales = this._scales;
        this.$task_scale.innerHTML = this._getScaleChunkHtml(scales, viewPort.x, viewPort.x_end);
      },

      getViewPort: function () {
        var scrollLeft = this.$config.scrollLeft || 0;
        var scrollTop = this.$config.scrollTop || 0;
        var height = this.$config.height || 0;
        var width = this.$config.width || 0;
        return {
          y: scrollTop,
          y_end: scrollTop + height,
          x: scrollLeft,
          x_end: scrollLeft + width,
          height: height,
          width: width
        };
      },

      _createLayerConfig: function () {
        var self = this;
        var taskFilter = function () {
          return self.isVisible();
        };

        var taskLayers = [
          {
            expose: true,
            renderer: this.$gantt.$ui.layers.taskBar(),
            container: this.$task_bars,
            filter: [taskFilter]
          },
          {
            renderer: this.$gantt.$ui.layers.taskSplitBar(),
            filter: [taskFilter],
            container: this.$task_bars,
            append: true
          },
          {
            renderer: this.$gantt.$ui.layers.taskBg(),
            container: this.$task_bg,
            filter: [
              //function(){
              //	return !self.$getConfig().static_background;
              //},
              taskFilter
            ]
          }
        ];

        var linkLayers = [
          {
            expose: true,
            renderer: this.$gantt.$ui.layers.link(),
            container: this.$task_links,
            filter: [taskFilter]
          }
        ];

        return {
          tasks: taskLayers,
          links: linkLayers
        };

      },

      _attachLayers: function (gantt) {
        this._taskLayers = [];
        this._linkLayers = [];

        var self = this;
        var getViewPort = function () {
          return self.getViewPort();
        };
        var layers = this.$gantt.$services.getService("layers");

        function subscribeSmartRender(layer) {
          self.attachEvent("onScroll", function () {
            if (layer.requestUpdate) {
              layer.requestUpdate();
            }
          });
        }

        if (this.$config.bind) {

          this._bindStore();
          var taskRenderer = layers.getDataRender(this.$config.bind);

          if (!taskRenderer) {
            taskRenderer = layers.createDataRender({
              name: this.$config.bind,
              defaultContainer: function () { return self.$task_data; }
            });
          }

          taskRenderer.container = function () { return self.$task_data; };

          var taskLayers = this.$config.layers;
          for (var i = 0; taskLayers && i < taskLayers.length; i++) {
            var layer = taskLayers[i];

            if (typeof layer == "string") {
              layer = this.$gantt.$ui.layers[layer]();
            }

            if (typeof layer == "function" || (layer && layer.render && layer.update)) {
              layer = { renderer: layer };
            }

            layer.host = this;
            if (!layer.viewPort) {
              var self = this;
              layer.getViewPort = function () {
                if (!self.getViewPort) {
                  return null;
                }
                return self.getViewPort();
              };
            }

            layer.getViewPort = getViewPort;
            subscribeSmartRender(layer);
            var bar_layer = taskRenderer.addLayer(layer);
            this._taskLayers.push(bar_layer);
            if (layer.expose) {
              this._taskRenderer = taskRenderer.getLayer(bar_layer);
            }
          }

          this._initStaticBackgroundRender();
        }

        if (this.$config.bindLinks) {
          self.$config.linkStore = self.$gantt.getDatastore(self.$config.bindLinks);

          var linkRenderer = layers.getDataRender(this.$config.bindLinks);

          if (!linkRenderer) {
            linkRenderer = layers.createDataRender({
              name: this.$config.bindLinks,
              defaultContainer: function () { return self.$task_data; }
            });
          }
          var linkLayers = this.$config.linkLayers;
          for (var i = 0; linkLayers && i < linkLayers.length; i++) {

            if (typeof layer == "string") {
              layer = this.$gantt.$ui.layers[layer]();
            }

            var layer = linkLayers[i];
            layer.host = this;
            layer.getViewPort = getViewPort;
            subscribeSmartRender(layer);
            var linkLayer = linkRenderer.addLayer(layer);
            this._taskLayers.push(linkLayer);
            if (linkLayers[i].expose) {
              this._linkRenderer = linkRenderer.getLayer(linkLayer);
            }
          }
        }
      },

      _initStaticBackgroundRender: function () {
        var self = this;
        var staticRender = canvasRender.create();
        var store = self.$config.rowStore;
        if (!store) return;

        this._staticBgHandler = store.attachEvent("onStoreUpdated", function (id, item, mode) {
          if (id !== null) {
            return;
          }

          if (!self.isVisible())
            return;
          var config = self.$getConfig();
          if (config.static_background) {
            var store = self.$gantt.getDatastore(self.$config.bind);
            var staticBgContainer = self.$task_bg_static;
            if (!staticBgContainer) {
              staticBgContainer = document.createElement("div");
              staticBgContainer.className = "gantt_task_bg";
              self.$task_bg_static = staticBgContainer;
              if (self.$task_bg.nextSibling) {
                self.$task_data.insertBefore(staticBgContainer, self.$task_bg.nextSibling);
              } else {
                self.$task_data.appendChild(staticBgContainer);
              }
            }
            if (store) {
              // staticRender.render(staticBgContainer, config, self.getScale(), config.row_height * store.countVisible());
              staticRender.render();
            }
          } else if (config.static_background) {
            if (self.$task_bg_static && self.$task_bg_static.parentNode) {
              self.$task_bg_static.parentNode.removeChild(self.$task_bg_static);
            }
          }
        });
        this.attachEvent("onDestroy", function () {
          staticRender.destroy();
        });
        this._initStaticBackgroundRender = function () { };//init once
      },

      _clearLayers: function (gantt) {
        var layers = this.$gantt.$services.getService("layers");
        var taskRenderer = layers.getDataRender(this.$config.bind);
        var linkRenderer = layers.getDataRender(this.$config.bindLinks);

        if (this._taskLayers) {
          for (var i = 0; i < this._taskLayers.length; i++) {
            taskRenderer.removeLayer(this._taskLayers[i]);
          }
        }
        if (this._linkLayers) {
          for (var i = 0; i < this._linkLayers.length; i++) {
            linkRenderer.removeLayer(this._linkLayers[i]);
          }
        }

        this._linkLayers = [];
        this._taskLayers = [];
      },

      _render_tasks_scales: function _render_tasks_scales() {
        var config = this.$getConfig();

        var scales_html = "",
          outer_width: any = 0,
          scale_height: any = 0;

        var state = this.$gantt.getState();

        if (this.isVisible()) {
          var helpers = this.$scaleHelper;
          var scales = this._getScales();
          scale_height = config.scale_height;

          var availWidth = this.$config.width;
          if (config.autosize == "x" || config.autosize == "xy") {
            availWidth = Math.max(config.autosize_min_width, 0);
          }

          var cfgs = helpers.prepareConfigs(scales, config.min_column_width, availWidth, scale_height - 1, state.min_date, state.max_date, config.rtl);
          var cfg = this._tasks = cfgs[cfgs.length - 1];
          this._scales = cfgs;
          this._posFromDateCache = {};

          scales_html = this._getScaleChunkHtml(cfgs, 0, this.$config.width);

          outer_width = cfg.full_width + "px";//cfg.full_width + (this._scroll_sizes().y ? scrollSizes.scroll_size : 0) + "px";
          scale_height += "px";
        }

        this.$task_scale.style.height = scale_height;

        this.$task_data.style.width =
          this.$task_scale.style.width = outer_width;

        this.$task_scale.innerHTML = scales_html;

      },

      _getScaleChunkHtml: function _get_scale_chunk_html(scales, fromPos, toPos) {
        var templates = this.$gantt.$services.templates();
        var html = [];

        var css = templates.scale_row_class;
        for (var i = 0; i < scales.length; i++) {
          var cssClass = "gantt_scale_line";
          var tplClass = css(scales[i]);
          if (tplClass) {
            cssClass += " " + tplClass;
          }

          html.push("<div class=\"" + cssClass + "\" style=\"height:" + (scales[i].height) +
            "px;position:relative;line-height:" + (scales[i].height) + "px\">" + this._prepareScaleHtml(scales[i], fromPos, toPos) + "</div>");
        }

        return html.join("");
      },
      _prepareScaleHtml: function _prepare_scale_html(config, fromPos, toPos) {
        var globalConfig = this.$getConfig();
        var globalTemplates = this.$gantt.$services.templates();

        var cells = [];
        var date = null, css = null;

        var content = config.format || config.template || config.date;

        if (typeof content === "string") {
          content = this.$gantt.date.date_to_str(content);
        }

        var startIndex = 0,
          endIndex = config.count;

        if (globalConfig.smart_scales && (!isNaN(fromPos) && !isNaN(toPos))) {
          startIndex = _findBinary(config.left, fromPos);
          endIndex = _findBinary(config.left, toPos) + 1;
        }

        css = config.css || function () {
        };
        if (!config.css && globalConfig.inherit_scale_class) {
          css = globalTemplates.scale_cell_class;
        }

        for (var i = startIndex; i < endIndex; i++) {
          if (!config.trace_x[i]) break;

          date = new Date(config.trace_x[i]);
          var value = content.call(this, date),
            width = config.width[i],
            height = config.height,
            left = config.left[i],
            style = "",
            template = "",
            cssclass = "";

          if (width) {
            var position = globalConfig.smart_scales ? ("position:absolute;left:" + left + "px") : "";

            style = "width:" + (width) + "px;height:" + height + "px;" + position;
            cssclass = "gantt_scale_cell" + (i == config.count - 1 ? " gantt_last_cell" : "");

            template = css.call(this, date);
            if (template) cssclass += " " + template;

            var ariaAttr = this.$gantt._waiAria.getTimelineCellAttr(value);
            var cell = "<div class='" + cssclass + "'" + ariaAttr + " style='" + style + "'>" + value + "</div>";
            cells.push(cell);
          } else {
            //do not render ignored cells
          }

        }
        return cells.join("");
      },
      dateFromPos: function dateFromPos(x) {
        var scale = this._tasks;
        if (x < 0 || x > scale.full_width || !scale.full_width) {
          return null;
        }

        var ind = _findBinary(this._tasks.left, x);
        var summ = this._tasks.left[ind];

        var col_width = scale.width[ind] || scale.col_width;
        var part = 0;
        if (col_width) {
          part = (x - summ) / col_width;
          if (scale.rtl) {
            part = 1 - part;
          }

        }

        var unit = 0;
        if (part) {
          unit = this._getColumnDuration(scale, scale.trace_x[ind]);
        }

        var date = new Date(scale.trace_x[ind].valueOf() + Math.round(part * unit));
        return date;
      },
      posFromDate: function posFromDate(date) {
        if (!this.isVisible())
          return 0;

        if (!date) {
          return 0;
        }

        var dateValue = String(date.valueOf());

        if (this._posFromDateCache[dateValue] !== undefined) {
          return this._posFromDateCache[dateValue];
        }
        var ind = this.columnIndexByDate(date);
        this.$gantt.assert(ind >= 0, "Invalid day index");

        var wholeCells = Math.floor(ind);
        var partCell = ind % 1;

        var pos = this._tasks.left[Math.min(wholeCells, this._tasks.width.length - 1)];
        if (wholeCells == this._tasks.width.length)
          pos += this._tasks.width[this._tasks.width.length - 1];
        //for(var i=1; i <= wholeCells; i++)
        //	pos += gantt._tasks.width[i-1];

        if (partCell) {
          if (wholeCells < this._tasks.width.length) {
            pos += this._tasks.width[wholeCells] * (partCell % 1);
          } else {
            pos += 1;
          }

        }

        var roundPos = Math.round(pos);
        this._posFromDateCache[dateValue] = roundPos;
        return Math.round(roundPos);
      },

      _getNextVisibleColumn: function (startIndex, columns, ignores) {
        // iterate columns to the right
        var date = +columns[startIndex];
        var visibleDateIndex = startIndex;
        while (ignores[date]) {
          visibleDateIndex++;
          date = +columns[visibleDateIndex];
        }

        return visibleDateIndex;
      },
      _getPrevVisibleColumn: function (startIndex, columns, ignores) {
        // iterate columns to the left
        var date = +columns[startIndex];
        var visibleDateIndex = startIndex;
        while (ignores[date]) {
          visibleDateIndex--;
          date = +columns[visibleDateIndex];
        }
        return visibleDateIndex;
      },
      _getClosestVisibleColumn: function (startIndex, columns, ignores) {
        var visibleDateIndex = this._getNextVisibleColumn(startIndex, columns, ignores);
        if (!columns[visibleDateIndex]) {
          visibleDateIndex = this._getPrevVisibleColumn(startIndex, columns, ignores);
        }
        return visibleDateIndex;
      },
      columnIndexByDate: function columnIndexByDate(date) {
        var pos = new Date(date).valueOf();
        var days = this._tasks.trace_x_ascending,
          ignores = this._tasks.ignore_x;

        var state = this.$gantt.getState();

        if (pos <= state.min_date) {
          if (this._tasks.rtl) {
            return days.length;
          } else {
            return 0;
          }

        }

        if (pos >= state.max_date) {
          if (this._tasks.rtl) {
            return 0;
          } else {
            return days.length;
          }
        }

        var dateIndex = _findBinary(days, pos);

        var visibleIndex = this._getClosestVisibleColumn(dateIndex, days, ignores);
        var visibleDate = days[visibleIndex];
        var transition = this._tasks.trace_index_transition;

        if (!visibleDate) {
          if (transition) {
            return transition[0];
          } else {
            return 0;
          }
        }

        var part = ((date - days[visibleIndex]) / this._getColumnDuration(this._tasks, days[visibleIndex]));
        if (transition) {
          return transition[visibleIndex] + (1 - part);
        } else {
          return visibleIndex + part;
        }
      },
      getItemPosition: function (task, start_date, end_date) {
        var xLeft, xRight, width;
        if (this._tasks.rtl) {
          xRight = this.posFromDate(start_date || task.start_date);
          xLeft = this.posFromDate(end_date || task.end_date);
        } else {
          xLeft = this.posFromDate(start_date || task.start_date);
          xRight = this.posFromDate(end_date || task.end_date);
        }
        width = Math.max((xRight - xLeft), 0);

        var y = this.getItemTop(task.id);
        var height = this.getItemHeight();
        return {
          left: xLeft,
          top: y,
          height: height,
          width: width
        };
      },

      getItemHeight: function () {
        var config = this.$getConfig();

        // height of the bar item
        var height = config.task_height;

        if (height == "full") {
          var offset = config.task_height_offset || 5;
          height = config.row_height - offset;
        }
        //item height cannot be bigger than row height
        height = Math.min(height, config.row_height);
        return Math.max(height, 0);
      },

      getScale: function () {
        return this._tasks;
      },

      _getScales: function _get_scales() {
        var config = this.$getConfig();
        var helpers = this.$scaleHelper;
        var scales = [helpers.primaryScale(config)].concat(helpers.getSubScales(config));

        helpers.sortScales(scales);
        return scales;
      },

      _getColumnDuration: function _get_coll_duration(scale, date) {
        return this.$gantt.date.add(date, scale.step, scale.unit) - date;
      },
      _bindStore: function () {
        if (this.$config.bind) {
          var rowStore = this.$gantt.getDatastore(this.$config.bind);
          this.$config.rowStore = rowStore;
          if (rowStore && !rowStore._timelineCacheAttached) {
            var self = this;
            rowStore._timelineCacheAttached = rowStore.attachEvent("onBeforeFilter", function () {
              self._resetTopPositionHeight();
            });
          }
        }
      },
      _unbindStore: function () {
        if (this.$config.bind) {
          var rowStore = this.$gantt.getDatastore(this.$config.bind);
          if (rowStore._timelineCacheAttached) {
            rowStore.detachEvent(rowStore._timelineCacheAttached);
            rowStore._timelineCacheAttached = false;
          }
        }
      },
      refresh: function () {
        this._bindStore();

        if (this.$config.bindLinks) {
          this.$config.linkStore = this.$gantt.getDatastore(this.$config.bindLinks);
        }

        this._resetTopPositionHeight();
        this._initStaticBackgroundRender();
        this._render_tasks_scales();
      },

      destructor: function () {
        var gantt = this.$gantt;
        this._clearLayers(gantt);
        this._unbindStore();
        this.$task = null;
        this.$task_scale = null;
        this.$task_data = null;
        this.$task_bg = null;
        this.$task_links = null;
        this.$task_bars = null;

        this.$gantt = null;

        if (this.$config.rowStore) {
          this.$config.rowStore.detachEvent(this._staticBgHandler);
          this.$config.rowStore = null;
        }
        if (this.$config.linkStore) {
          this.$config.linkStore = null;
        }

        this.callEvent("onDestroy", []);
        this.detachAllEvents();

      }
    };

    return Timeline;

    function _findBinary(array, target) {
      // modified binary search, target value not exactly match array elements, looking for closest one

      var low = 0, high = array.length - 1, i, item, prev;
      while (low <= high) {

        i = Math.floor((low + high) / 2);
        item = +array[i];
        prev = +array[i - 1];
        if (item < target) {
          low = i + 1;
          continue;
        }
        if (item > target) {
          if (!(!isNaN(prev) && prev < target)) {
            high = i - 1;
            continue;
          } else {
            // if target is between 'i' and 'i-1' return 'i - 1'
            return i - 1;
          }

        }
        while (+array[i] == +array[i + 1]) i++;

        return i;
      }
      return array.length - 1;
    }



    /***/
  }


   // ui service function
  // for removing cirular dependancy

  mouseEventContainer(gantt) {
    var events = [];

    return {
      delegate: function (event, className, handler, root) {
        events.push([event, className, handler, root]);

        var helper = gantt.$services.getService("mouseEvents");
        helper.delegate(event, className, handler, root);
      },
      destructor: function () {
        var mouseEvents = gantt.$services.getService("mouseEvents");
        for (var i = 0; i < events.length; i++) {
          var h = events[i];
          mouseEvents.detach(h[0], h[1], h[2], h[3]);
        }
        events = [];
      }
    };
  }

  rowPositionMixin() {

    function createMixin() {
      var topCache = {};
      return {
        _resetTopPositionHeight: function () {
          topCache = {};
        },

        /**
         * Get top coordinate by row index (order)
         * @param {number} index
         */
        getRowTop: function (index) {
          return index * this.$getConfig().row_height;
        },

        /**
         * Get top coordinate by item id
         * @param {*} task_id
         */
        getItemTop: function (taskId) {
          if (this.$config.rowStore) {
            if (topCache[taskId] !== undefined) {
              return topCache[taskId];
            }
            var store = this.$config.rowStore;
            if (!store) return 0;

            var itemIndex = store.getIndexById(taskId);

            if (itemIndex === -1 && store.getParent && store.exists(taskId)) {
              var parentId = store.getParent(taskId);
              if (store.exists(parentId)) {
                // if task is not found in list - maybe it's parent is a split task and we should use parents index instead
                var parent = store.getItem(parentId);
                if (this.$gantt.isSplitTask(parent)) {
                  return this.getRowTop(store.getIndexById(parent.id));
                }
              }
            }
            topCache[taskId] = this.getRowTop(itemIndex);
            return topCache[taskId];
          } else {
            return 0;
          }

        }
      };
    }

    return createMixin;

    /***/
  }

}
