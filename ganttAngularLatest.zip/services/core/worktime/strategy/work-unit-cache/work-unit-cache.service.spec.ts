import { TestBed } from '@angular/core/testing';

import { WorkUnitCacheService } from './work-unit-cache.service';

describe('WorkUnitCacheService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WorkUnitCacheService = TestBed.get(WorkUnitCacheService);
    expect(service).toBeTruthy();
  });
});
